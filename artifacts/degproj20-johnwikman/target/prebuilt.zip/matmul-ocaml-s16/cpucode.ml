open Printf



let main =
    let fun1_head arg0_s =
        Array.get (arg0_s) (0)
    in
    let fun3_tail arg2_s =
        (fun xs start len -> Array.sub xs (min ((Array.length xs) - 1) start) (min ((Array.length xs) - start) len)) (arg2_s) (1) (Array.length (arg2_s))
    in
    let fun5_null arg4_l =
        ( = ) (Array.length (arg4_l)) (0)
    in
    let fun8_map arg6_f arg7_seq =
        Array.map (arg6_f) (arg7_seq)
    in
    let fun11_mapi arg9_f arg10_seq =
        Array.mapi (arg9_f) (arg10_seq)
    in
    let fun14_seqInit arg12_size arg13_f =
        Array.init (arg12_size) (arg13_f)
    in
    let rec fun16_int2string_rechelper arg17_n =
            if ( < ) (arg17_n) (10) then
                [|char_of_int (( + ) (arg17_n) (int_of_char ('0')))|]
            else
                let var18_d  =
                    [|char_of_int (( + ) (( mod ) (arg17_n) (10)) (int_of_char ('0')))|]
                in
                Array.append (fun16_int2string_rechelper (( / ) (arg17_n) (10))) (var18_d)
    in
    let fun19_int2string arg15_n =
        if ( < ) (arg15_n) (0) then
            (fun x xs -> Array.append [|x|] xs) ('-') (fun16_int2string_rechelper (( ~- ) (arg15_n)))
        else
            fun16_int2string_rechelper (arg15_n)
    in
    let fun21_float2string arg20_f =
        Array.of_seq (String.to_seq (string_of_float (arg20_f)))
    in
    let rec fun22_strJoin arg23_delim arg24_strs =
            if ( = ) (Array.length (arg24_strs)) (0) then
                [||]
            else
                if ( = ) (Array.length (arg24_strs)) (1) then
                    fun1_head (arg24_strs)
                else
                    Array.append (Array.append (fun1_head (arg24_strs)) (arg23_delim)) (fun22_strJoin (arg23_delim) (fun3_tail (arg24_strs)))
    in
    let fun26_printint arg25_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg25_i))
    in
    let fun28_printintln arg27_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (Array.append (fun19_int2string (arg27_i)) ([|'\n'|]))
    in
    let rec fun31_printloop arg33_arr arg32_i =
            if ( = ) (arg32_i) (Array.length (arg33_arr)) then
                ()
            else
                let var34__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var35__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg32_i))
                in
                let var36__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var37__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg33_arr) (arg32_i)))
                in
                let var38__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun31_printloop (arg33_arr) (( + ) (arg32_i) (1))
    in
    let fun42_printintarr arg29_name arg30_arr =
        let var39__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var40__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg29_name)
        in
        let var41__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun31_printloop (arg30_arr) (0)
    in
    let rec fun45_printloop arg47_arr arg46_i =
            if ( = ) (arg46_i) (Array.length (arg47_arr)) then
                ()
            else
                let var48__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var49__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg46_i))
                in
                let var50__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var51__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg47_arr) (arg46_i)))
                in
                let var52__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun45_printloop (arg47_arr) (( + ) (arg46_i) (1))
    in
    let fun56_printfloatarr arg43_name arg44_arr =
        let var53__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var54__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg43_name)
        in
        let var55__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun45_printloop (arg44_arr) (0)
    in
    let rec fun59_printloop arg62_vec arg61_size arg60_i =
            if ( = ) (arg60_i) (arg61_size) then
                ()
            else
                let var63__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg62_vec) (arg60_i)))
                in
                let var64__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun59_printloop (arg62_vec) (arg61_size) (( + ) (arg60_i) (1))
    in
    let fun66_printSeqi arg57_size arg58_vec =
        let var65__  =
            fun59_printloop (arg58_vec) (arg57_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let rec fun69_printloop arg72_vec arg71_size arg70_i =
            if ( = ) (arg70_i) (arg71_size) then
                ()
            else
                let var73__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg72_vec) (arg70_i)))
                in
                let var74__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun69_printloop (arg72_vec) (arg71_size) (( + ) (arg70_i) (1))
    in
    let fun76_printSeqf arg67_size arg68_vec =
        let var75__  =
            fun69_printloop (arg68_vec) (arg67_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let fun80_matrixMkf arg77_rows arg78_cols arg79_v =
        Array.make (( * ) (arg77_rows) (arg78_cols)) (arg79_v)
    in
    let fun86_matrixGetf arg81_row arg82_col arg83_m_rows arg84_m_cols arg85_m =
        Array.get (arg85_m) (( + ) (( * ) (arg84_m_cols) (arg81_row)) (arg82_col))
    in
    let fun95_seqInitFun arg94_f arg91_cols arg90_i =
        let var92_row  =
            ( / ) (arg90_i) (arg91_cols)
        in
        let var93_col  =
            ( mod ) (arg90_i) (arg91_cols)
        in
        arg94_f (var92_row) (var93_col)
    in
    let fun96_matrixInitf arg87_rows arg88_cols arg89_f =
        fun14_seqInit (( * ) (arg87_rows) (arg88_cols)) (fun95_seqInitFun (arg89_f) (arg88_cols))
    in
    let rec fun100_printrc arg107_m arg104_m_cols arg103_m_rows arg101_row arg102_col =
            if ( = ) (arg101_row) (arg103_m_rows) then
                [||]
            else
                let var105_next_col  =
                    ( mod ) (( + ) (arg102_col) (1)) (arg104_m_cols)
                in
                let var106_next_row  =
                    if ( = ) (var105_next_col) (0) then
                        ( + ) (arg101_row) (1)
                    else
                        arg101_row
                in
                fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg101_row) (arg102_col) (arg103_m_rows) (arg104_m_cols) (arg107_m)); if ( = ) (var105_next_col) (0) then
                    [|'\n'|]
                else
                    [|' '|]; fun100_printrc (arg107_m) (arg104_m_cols) (arg103_m_rows) (var106_next_row) (var105_next_col)|])
    in
    let fun108_matrix2strf arg97_m_rows arg98_m_cols arg99_m =
        fun100_printrc (arg99_m) (arg98_m_cols) (arg97_m_rows) (0) (0)
    in
    let rec fun112_printrc arg119_m arg116_m_cols arg115_m_rows arg113_row arg114_col =
            if ( = ) (arg113_row) (arg115_m_rows) then
                [||]
            else
                let var117_next_col  =
                    ( mod ) (( + ) (arg114_col) (1)) (arg116_m_cols)
                in
                let var118_next_row  =
                    if ( = ) (var117_next_col) (0) then
                        ( + ) (arg113_row) (1)
                    else
                        arg113_row
                in
                let var120__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg113_row) (arg114_col) (arg115_m_rows) (arg116_m_cols) (arg119_m)); if ( = ) (var117_next_col) (0) then
                        [|'\n'|]
                    else
                        [|' '|]|]))
                in
                fun112_printrc (arg119_m) (arg116_m_cols) (arg115_m_rows) (var118_next_row) (var117_next_col)
    in
    let fun121_printMatrixf arg109_m_rows arg110_m_cols arg111_m =
        fun112_printrc (arg111_m) (arg110_m_cols) (arg109_m_rows) (0) (0)
    in
    let rec fun132_dotprod arg140_b_cols arg139_b arg138_a arg137_innerDim arg133_acc arg134_p arg135_a_offset arg136_b_offset =
            if ( = ) (arg134_p) (arg137_innerDim) then
                arg133_acc
            else
                fun132_dotprod (arg140_b_cols) (arg139_b) (arg138_a) (arg137_innerDim) (( +. ) (arg133_acc) (( *. ) (Array.get (arg138_a) (arg135_a_offset)) (Array.get (arg139_b) (arg136_b_offset)))) (( + ) (arg134_p) (1)) (( + ) (arg135_a_offset) (1)) (( + ) (arg136_b_offset) (arg140_b_cols))
    in
    let fun141_matrixMulfWorker arg122_innerDim arg123_a_rows arg124_b_cols arg125_a arg126_b arg127_idx =
        let var128_row  =
            ( / ) (arg127_idx) (arg124_b_cols)
        in
        let var129_col  =
            ( mod ) (arg127_idx) (arg124_b_cols)
        in
        let var130_a_start_offset  =
            ( * ) (arg122_innerDim) (var128_row)
        in
        let var131_b_start_offset  =
            var129_col
        in
        fun132_dotprod (arg124_b_cols) (arg126_b) (arg125_a) (arg122_innerDim) (0.0) (0) (var130_a_start_offset) (var131_b_start_offset)
    in
    let rec fun152_dotprod arg159_outerDim arg158_a arg157_innerDim arg153_acc arg154_p arg155_aT_offset arg156_a_offset =
            if ( = ) (arg154_p) (arg157_innerDim) then
                arg153_acc
            else
                fun152_dotprod (arg159_outerDim) (arg158_a) (arg157_innerDim) (( +. ) (arg153_acc) (( *. ) (Array.get (arg158_a) (arg155_aT_offset)) (Array.get (arg158_a) (arg156_a_offset)))) (( + ) (arg154_p) (1)) (( + ) (arg155_aT_offset) (arg159_outerDim)) (( + ) (arg156_a_offset) (arg159_outerDim))
    in
    let fun160_matrixATAfWorker arg142_rows arg143_cols arg144_a arg145_idx =
        let var146_innerDim  =
            arg142_rows
        in
        let var147_outerDim  =
            arg143_cols
        in
        let var148_row  =
            ( / ) (arg145_idx) (arg143_cols)
        in
        let var149_col  =
            ( mod ) (arg145_idx) (arg143_cols)
        in
        let var150_aT_start_offset  =
            var148_row
        in
        let var151_a_start_offset  =
            var149_col
        in
        fun152_dotprod (var147_outerDim) (arg144_a) (var146_innerDim) (0.0) (0) (var150_aT_start_offset) (var151_a_start_offset)
    in
    let rec fun172_dotprodTransposeLhs arg181_b_cols arg180_a_cols arg179_b arg178_a arg177_b_rows arg173_acc arg174_p arg175_aT_offset arg176_b_offset =
            if ( = ) (arg174_p) (arg177_b_rows) then
                arg173_acc
            else
                fun172_dotprodTransposeLhs (arg181_b_cols) (arg180_a_cols) (arg179_b) (arg178_a) (arg177_b_rows) (( +. ) (arg173_acc) (( *. ) (Array.get (arg178_a) (arg175_aT_offset)) (Array.get (arg179_b) (arg176_b_offset)))) (( + ) (arg174_p) (1)) (( + ) (arg175_aT_offset) (arg180_a_cols)) (( + ) (arg176_b_offset) (arg181_b_cols))
    in
    let fun182_matrixMulTransposeLhsfWorker arg161_a_rows arg162_a_cols arg163_b_rows arg164_b_cols arg165_a arg166_b arg167_idx =
        let var168_row  =
            ( / ) (arg167_idx) (arg164_b_cols)
        in
        let var169_col  =
            ( mod ) (arg167_idx) (arg164_b_cols)
        in
        let var170_aT_start_offset  =
            var168_row
        in
        let var171_b_start_offset  =
            var169_col
        in
        fun172_dotprodTransposeLhs (arg164_b_cols) (arg162_a_cols) (arg166_b) (arg165_a) (arg163_b_rows) (0.0) (0) (var170_aT_start_offset) (var171_b_start_offset)
    in
    let fun189_matAinitfun arg187_row arg188_col =
        float_of_int (( + ) (( * ) (arg187_row) (arg187_row)) (arg188_col))
    in
    let fun192_matBinitfun arg190_row arg191_col =
        ( /. ) (float_of_int (( / ) (( * ) (( + ) (arg190_row) (19)) (17)) (( + ) (arg191_col) (13)))) (float_of_int (( + ) (arg190_row) (11)))
    in
    let fun195_matAinitfun_v2 arg193_row arg194_col =
        ( -. ) (( /. ) (float_of_int (( + ) (( * ) (arg193_row) (arg193_row)) (arg194_col))) (3.0e+0)) (1.400000e-2)
    in
    let fun198_matBinitfun_v2 arg196_row arg197_col =
        float_of_int (( mod ) (( / ) (( * ) (( + ) (arg196_row) (19)) (17)) (( + ) (arg197_col) (13))) (2))
    in
    let fun211_bm_runonce arg208_matB arg207_matA arg206_innerDim arg205_matB_cols arg204_matA_rows arg202__ =
        let var203_bm_t_start  =
            Unix.gettimeofday (())
        in
        let var209_matAxB  =
            fun14_seqInit (( * ) (arg204_matA_rows) (arg205_matB_cols)) (fun141_matrixMulfWorker (arg206_innerDim) (arg204_matA_rows) (arg205_matB_cols) (arg207_matA) (arg208_matB))
        in
        let var210_bm_t_end  =
            Unix.gettimeofday (())
        in
        ( -. ) (var210_bm_t_end) (var203_bm_t_start)
    in
    let rec fun213_bm_iter arg222_matA_rows arg221_matB_cols arg220_innerDim arg219_matA arg218_matB arg216_n arg214_i arg215_acc =
            if ( >= ) (arg214_i) (arg216_n) then
                arg215_acc
            else
                let var217__  =
                    ()
                in
                let var223_res  =
                    fun211_bm_runonce (arg218_matB) (arg219_matA) (arg220_innerDim) (arg221_matB_cols) (arg222_matA_rows) (())
                in
                let var224_newacc  =
                    Array.append (arg215_acc) ([|var223_res|])
                in
                fun213_bm_iter (arg222_matA_rows) (arg221_matB_cols) (arg220_innerDim) (arg219_matA) (arg218_matB) (arg216_n) (( + ) (arg214_i) (1)) (var224_newacc)
    in
    let fun230_bm_runmultiple arg229_matB arg228_matA arg227_innerDim arg226_matB_cols arg225_matA_rows arg212_n =
        fun213_bm_iter (arg225_matA_rows) (arg226_matB_cols) (arg227_innerDim) (arg228_matA) (arg229_matB) (arg212_n) (0) ([||])
    in
    let rec fun233_quicksort_rec arg235_pivot arg236_lt_pivot arg237_geq_pivot arg238_remaining =
            if ( = ) (Array.length (arg238_remaining)) (0) then
                let var239_seq_lt  =
                    fun234_quicksort (arg236_lt_pivot)
                in
                let var240_seq_pivot  =
                    [|arg235_pivot|]
                in
                let var241_seq_geq  =
                    fun234_quicksort (arg237_geq_pivot)
                in
                Array.append (Array.append (var239_seq_lt) (var240_seq_pivot)) (var241_seq_geq)
            else
                let var242_e  =
                    fun1_head (arg238_remaining)
                in
                let var243_t  =
                    fun3_tail (arg238_remaining)
                in
                if ( < ) (var242_e) (arg235_pivot) then
                    fun233_quicksort_rec (arg235_pivot) ((fun x xs -> Array.append [|x|] xs) (var242_e) (arg236_lt_pivot)) (arg237_geq_pivot) (var243_t)
                else
                    fun233_quicksort_rec (arg235_pivot) (arg236_lt_pivot) ((fun x xs -> Array.append [|x|] xs) (var242_e) (arg237_geq_pivot)) (var243_t)
        and fun234_quicksort arg244_arr =
            if ( <= ) (Array.length (arg244_arr)) (1) then
                arg244_arr
            else
                fun233_quicksort_rec (fun1_head (arg244_arr)) ([||]) ([||]) (fun3_tail (arg244_arr))
    in
    let fun245_bm_sort arg231_arr =
        let var232_n  =
            Array.length (arg231_arr)
        in
        fun234_quicksort (arg231_arr)
    in
    let fun249_bm_median arg246_arr =
        let var247_n  =
            Array.length (arg246_arr)
        in
        let var248_sorted  =
            fun245_bm_sort (arg246_arr)
        in
        if ( = ) (( mod ) (var247_n) (2)) (0) then
            ( /. ) (( +. ) (Array.get (arg246_arr) (( - ) (( / ) (var247_n) (2)) (1))) (Array.get (arg246_arr) (( / ) (var247_n) (2)))) (2.0e+0)
        else
            Array.get (arg246_arr) (( / ) (var247_n) (2))
    in
    let rec fun252_work arg256_arr arg255_n arg253_i arg254_acc =
            if ( = ) (arg253_i) (arg255_n) then
                arg254_acc
            else
                fun252_work (arg256_arr) (arg255_n) (( + ) (arg253_i) (1)) (( +. ) (arg254_acc) (Array.get (arg256_arr) (arg253_i)))
    in
    let fun257_bm_sum arg250_arr =
        let var251_n  =
            Array.length (arg250_arr)
        in
        fun252_work (arg250_arr) (var251_n) (0) (0.0)
    in
    let rec fun260_work arg264_arr arg263_n arg261_i arg262_acc =
            if ( = ) (arg261_i) (arg263_n) then
                arg262_acc
            else
                let var265_e  =
                    Array.get (arg264_arr) (arg261_i)
                in
                fun260_work (arg264_arr) (arg263_n) (( + ) (arg261_i) (1)) (if ( > ) (var265_e) (arg262_acc) then
                    var265_e
                else
                    arg262_acc)
    in
    let fun266_bm_max arg258_arr =
        let var259_n  =
            Array.length (arg258_arr)
        in
        fun260_work (arg258_arr) (var259_n) (1) (Array.get (arg258_arr) (0))
    in
    let rec fun269_work arg273_arr arg272_n arg270_i arg271_acc =
            if ( = ) (arg270_i) (arg272_n) then
                arg271_acc
            else
                let var274_e  =
                    Array.get (arg273_arr) (arg270_i)
                in
                fun269_work (arg273_arr) (arg272_n) (( + ) (arg270_i) (1)) (if ( < ) (var274_e) (arg271_acc) then
                    var274_e
                else
                    arg271_acc)
    in
    let fun275_bm_min arg267_arr =
        let var268_n  =
            Array.length (arg267_arr)
        in
        fun269_work (arg267_arr) (var268_n) (1) (Array.get (arg267_arr) (0))
    in
    let rec fun280_work arg286_avg_co arg284_arr arg283_n arg281_i arg282_acc =
            if ( = ) (arg281_i) (arg283_n) then
                arg282_acc
            else
                let var285_elem  =
                    ( *. ) (Array.get (arg284_arr) (arg281_i)) (1.0e+3)
                in
                let var287_subres  =
                    ( -. ) (arg286_avg_co) (var285_elem)
                in
                fun280_work (arg286_avg_co) (arg284_arr) (arg283_n) (( + ) (arg281_i) (1)) (( +. ) (arg282_acc) (( *. ) (var287_subres) (var287_subres)))
    in
    let fun291_bm_variance arg276_avg arg277_arr =
        let var278_n  =
            Array.length (arg277_arr)
        in
        let var279_avg_co  =
            ( *. ) (arg276_avg) (1.0e+3)
        in
        let var288_elem  =
            ( *. ) (Array.get (arg277_arr) (0)) (1.0e+3)
        in
        let var289_subres  =
            ( -. ) (var279_avg_co) (var288_elem)
        in
        let var290_res  =
            fun280_work (var279_avg_co) (arg277_arr) (var278_n) (1) (( *. ) (var289_subres) (var289_subres))
        in
        ( /. ) (var290_res) (float_of_int (( - ) (var278_n) (1)))
    in
    let rec fun294_work arg298_arr arg296_n arg295_i =
            if ( = ) (arg295_i) (arg296_n) then
                ()
            else
                let var297__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|','; ' '|])
                in
                let var299__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg298_arr) (arg295_i)) (1.0e+3)))
                in
                fun294_work (arg298_arr) (arg296_n) (( + ) (arg295_i) (1))
    in
    let fun303_bm_printarr arg292_arr =
        let var293_n  =
            Array.length (arg292_arr)
        in
        let var300__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['|])
        in
        let var301__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg292_arr) (0)) (1.0e+3)))
        in
        let var302__  =
            fun294_work (arg292_arr) (var293_n) (1)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|']'|])
    in
    let fun306_bm_dist arg304_a arg305_b =
        if ( > ) (arg304_a) (arg305_b) then
            ( -. ) (arg304_a) (arg305_b)
        else
            ( -. ) (arg305_b) (arg304_a)
    in
    let var183_matA_rows  =
        16
    in
    let var184_matA_cols  =
        16
    in
    let var185_matB_rows  =
        16
    in
    let var186_matB_cols  =
        16
    in
    let var199_matA  =
        fun96_matrixInitf (var183_matA_rows) (var184_matA_cols) (fun195_matAinitfun_v2)
    in
    let var200_matB  =
        fun96_matrixInitf (var185_matB_rows) (var186_matB_cols) (fun198_matBinitfun_v2)
    in
    let var201_innerDim  =
        var184_matA_cols
    in
    let var307__  =
        ()
    in
    let var308_bmres_warmup  =
        fun230_bm_runmultiple (var200_matB) (var199_matA) (var201_innerDim) (var186_matB_cols) (var183_matA_rows) (4)
    in
    let var309__  =
        ()
    in
    let var310_bmres_iters  =
        fun230_bm_runmultiple (var200_matB) (var199_matA) (var201_innerDim) (var186_matB_cols) (var183_matA_rows) (15)
    in
    let var377__  =
        let var311_median  =
            fun249_bm_median (var310_bmres_iters)
        in
        let var312_sum  =
            fun257_bm_sum (var310_bmres_iters)
        in
        let var313_avg  =
            ( /. ) (var312_sum) (1.50e+1)
        in
        let var314_max  =
            fun266_bm_max (var310_bmres_iters)
        in
        let var315_min  =
            fun275_bm_min (var310_bmres_iters)
        in
        let var316_variance  =
            fun291_bm_variance (var313_avg) (var310_bmres_iters)
        in
        let var317_median  =
            ( *. ) (var311_median) (1.0e+3)
        in
        let var318_sum  =
            ( *. ) (var312_sum) (1.0e+3)
        in
        let var319_avg  =
            ( *. ) (var313_avg) (1.0e+3)
        in
        let var320_max  =
            ( *. ) (var314_max) (1.0e+3)
        in
        let var321_min  =
            ( *. ) (var315_min) (1.0e+3)
        in
        let var322__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var323__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var324__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'1'; '5'|])
        in
        let var325__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var326__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var327__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var317_median))
        in
        let var328__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var329__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var330__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var320_max))
        in
        let var331__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var332__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var333__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var321_min))
        in
        let var334__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var335__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var336__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var319_avg))
        in
        let var337__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var338__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var339__  =
            fun303_bm_printarr (var310_bmres_iters)
        in
        let var340__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var341__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var342__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var316_variance))
        in
        let var343__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var344_median  =
            fun249_bm_median (var308_bmres_warmup)
        in
        let var345_sum  =
            fun257_bm_sum (var308_bmres_warmup)
        in
        let var346_avg  =
            ( /. ) (var345_sum) (4.0e+0)
        in
        let var347_max  =
            fun266_bm_max (var308_bmres_warmup)
        in
        let var348_min  =
            fun275_bm_min (var308_bmres_warmup)
        in
        let var349_variance  =
            fun291_bm_variance (var346_avg) (var308_bmres_warmup)
        in
        let var350_median  =
            ( *. ) (var344_median) (1.0e+3)
        in
        let var351_sum  =
            ( *. ) (var345_sum) (1.0e+3)
        in
        let var352_avg  =
            ( *. ) (var346_avg) (1.0e+3)
        in
        let var353_max  =
            ( *. ) (var347_max) (1.0e+3)
        in
        let var354_min  =
            ( *. ) (var348_min) (1.0e+3)
        in
        let var355__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'; '\n'; '['; 'w'; 'a'; 'r'; 'm'; 'u'; 'p'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var356__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var357__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'4'|])
        in
        let var358__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var359__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var360__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var350_median))
        in
        let var361__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var362__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var363__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var353_max))
        in
        let var364__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var365__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var366__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var354_min))
        in
        let var367__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var368__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var369__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var352_avg))
        in
        let var370__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var371__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var372__  =
            fun303_bm_printarr (var308_bmres_warmup)
        in
        let var373__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var374__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var375__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var349_variance))
        in
        let var376__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        ()
    in
    ()