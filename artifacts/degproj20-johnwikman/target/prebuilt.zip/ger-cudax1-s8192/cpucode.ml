open Printf

external gpuhost_fun195_gerWorkerf: int array -> float array -> float array -> float array -> float array -> float array = "gpuhost_fun195_gerWorkerf"

let main =
    let fun1_head arg0_s =
        Array.get (arg0_s) (0)
    in
    let fun3_tail arg2_s =
        (fun xs start len -> Array.sub xs (min ((Array.length xs) - 1) start) (min ((Array.length xs) - start) len)) (arg2_s) (1) (Array.length (arg2_s))
    in
    let fun5_null arg4_l =
        ( = ) (Array.length (arg4_l)) (0)
    in
    let fun8_map arg6_f arg7_seq =
        Array.map (arg6_f) (arg7_seq)
    in
    let fun11_mapi arg9_f arg10_seq =
        Array.mapi (arg9_f) (arg10_seq)
    in
    let fun14_seqInit arg12_size arg13_f =
        Array.init (arg12_size) (arg13_f)
    in
    let rec fun16_int2string_rechelper arg17_n =
            if ( < ) (arg17_n) (10) then
                [|char_of_int (( + ) (arg17_n) (int_of_char ('0')))|]
            else
                let var18_d  =
                    [|char_of_int (( + ) (( mod ) (arg17_n) (10)) (int_of_char ('0')))|]
                in
                Array.append (fun16_int2string_rechelper (( / ) (arg17_n) (10))) (var18_d)
    in
    let fun19_int2string arg15_n =
        if ( < ) (arg15_n) (0) then
            (fun x xs -> Array.append [|x|] xs) ('-') (fun16_int2string_rechelper (( ~- ) (arg15_n)))
        else
            fun16_int2string_rechelper (arg15_n)
    in
    let fun21_float2string arg20_f =
        Array.of_seq (String.to_seq (string_of_float (arg20_f)))
    in
    let rec fun22_strJoin arg23_delim arg24_strs =
            if ( = ) (Array.length (arg24_strs)) (0) then
                [||]
            else
                if ( = ) (Array.length (arg24_strs)) (1) then
                    fun1_head (arg24_strs)
                else
                    Array.append (Array.append (fun1_head (arg24_strs)) (arg23_delim)) (fun22_strJoin (arg23_delim) (fun3_tail (arg24_strs)))
    in
    let fun26_printint arg25_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg25_i))
    in
    let fun28_printintln arg27_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (Array.append (fun19_int2string (arg27_i)) ([|'\n'|]))
    in
    let rec fun31_printloop arg33_arr arg32_i =
            if ( = ) (arg32_i) (Array.length (arg33_arr)) then
                ()
            else
                let var34__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var35__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg32_i))
                in
                let var36__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var37__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg33_arr) (arg32_i)))
                in
                let var38__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun31_printloop (arg33_arr) (( + ) (arg32_i) (1))
    in
    let fun42_printintarr arg29_name arg30_arr =
        let var39__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var40__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg29_name)
        in
        let var41__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun31_printloop (arg30_arr) (0)
    in
    let rec fun45_printloop arg47_arr arg46_i =
            if ( = ) (arg46_i) (Array.length (arg47_arr)) then
                ()
            else
                let var48__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var49__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg46_i))
                in
                let var50__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var51__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg47_arr) (arg46_i)))
                in
                let var52__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun45_printloop (arg47_arr) (( + ) (arg46_i) (1))
    in
    let fun56_printfloatarr arg43_name arg44_arr =
        let var53__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var54__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg43_name)
        in
        let var55__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun45_printloop (arg44_arr) (0)
    in
    let rec fun59_printloop arg62_vec arg61_size arg60_i =
            if ( = ) (arg60_i) (arg61_size) then
                ()
            else
                let var63__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg62_vec) (arg60_i)))
                in
                let var64__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun59_printloop (arg62_vec) (arg61_size) (( + ) (arg60_i) (1))
    in
    let fun66_printSeqi arg57_size arg58_vec =
        let var65__  =
            fun59_printloop (arg58_vec) (arg57_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let rec fun69_printloop arg72_vec arg71_size arg70_i =
            if ( = ) (arg70_i) (arg71_size) then
                ()
            else
                let var73__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg72_vec) (arg70_i)))
                in
                let var74__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun69_printloop (arg72_vec) (arg71_size) (( + ) (arg70_i) (1))
    in
    let fun76_printSeqf arg67_size arg68_vec =
        let var75__  =
            fun69_printloop (arg68_vec) (arg67_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let fun80_matrixMkf arg77_rows arg78_cols arg79_v =
        Array.make (( * ) (arg77_rows) (arg78_cols)) (arg79_v)
    in
    let fun86_matrixGetf arg81_row arg82_col arg83_m_rows arg84_m_cols arg85_m =
        Array.get (arg85_m) (( + ) (( * ) (arg84_m_cols) (arg81_row)) (arg82_col))
    in
    let fun95_seqInitFun arg94_f arg91_cols arg90_i =
        let var92_row  =
            ( / ) (arg90_i) (arg91_cols)
        in
        let var93_col  =
            ( mod ) (arg90_i) (arg91_cols)
        in
        arg94_f (var92_row) (var93_col)
    in
    let fun96_matrixInitf arg87_rows arg88_cols arg89_f =
        fun14_seqInit (( * ) (arg87_rows) (arg88_cols)) (fun95_seqInitFun (arg89_f) (arg88_cols))
    in
    let rec fun100_printrc arg107_m arg104_m_cols arg103_m_rows arg101_row arg102_col =
            if ( = ) (arg101_row) (arg103_m_rows) then
                [||]
            else
                let var105_next_col  =
                    ( mod ) (( + ) (arg102_col) (1)) (arg104_m_cols)
                in
                let var106_next_row  =
                    if ( = ) (var105_next_col) (0) then
                        ( + ) (arg101_row) (1)
                    else
                        arg101_row
                in
                fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg101_row) (arg102_col) (arg103_m_rows) (arg104_m_cols) (arg107_m)); if ( = ) (var105_next_col) (0) then
                    [|'\n'|]
                else
                    [|' '|]; fun100_printrc (arg107_m) (arg104_m_cols) (arg103_m_rows) (var106_next_row) (var105_next_col)|])
    in
    let fun108_matrix2strf arg97_m_rows arg98_m_cols arg99_m =
        fun100_printrc (arg99_m) (arg98_m_cols) (arg97_m_rows) (0) (0)
    in
    let rec fun112_printrc arg119_m arg116_m_cols arg115_m_rows arg113_row arg114_col =
            if ( = ) (arg113_row) (arg115_m_rows) then
                [||]
            else
                let var117_next_col  =
                    ( mod ) (( + ) (arg114_col) (1)) (arg116_m_cols)
                in
                let var118_next_row  =
                    if ( = ) (var117_next_col) (0) then
                        ( + ) (arg113_row) (1)
                    else
                        arg113_row
                in
                let var120__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg113_row) (arg114_col) (arg115_m_rows) (arg116_m_cols) (arg119_m)); if ( = ) (var117_next_col) (0) then
                        [|'\n'|]
                    else
                        [|' '|]|]))
                in
                fun112_printrc (arg119_m) (arg116_m_cols) (arg115_m_rows) (var118_next_row) (var117_next_col)
    in
    let fun121_printMatrixf arg109_m_rows arg110_m_cols arg111_m =
        fun112_printrc (arg111_m) (arg110_m_cols) (arg109_m_rows) (0) (0)
    in
    let rec fun132_dotprod arg140_b_cols arg139_b arg138_a arg137_innerDim arg133_acc arg134_p arg135_a_offset arg136_b_offset =
            if ( = ) (arg134_p) (arg137_innerDim) then
                arg133_acc
            else
                fun132_dotprod (arg140_b_cols) (arg139_b) (arg138_a) (arg137_innerDim) (( +. ) (arg133_acc) (( *. ) (Array.get (arg138_a) (arg135_a_offset)) (Array.get (arg139_b) (arg136_b_offset)))) (( + ) (arg134_p) (1)) (( + ) (arg135_a_offset) (1)) (( + ) (arg136_b_offset) (arg140_b_cols))
    in
    let fun141_matrixMulfWorker arg122_innerDim arg123_a_rows arg124_b_cols arg125_a arg126_b arg127_idx =
        let var128_row  =
            ( / ) (arg127_idx) (arg124_b_cols)
        in
        let var129_col  =
            ( mod ) (arg127_idx) (arg124_b_cols)
        in
        let var130_a_start_offset  =
            ( * ) (arg122_innerDim) (var128_row)
        in
        let var131_b_start_offset  =
            var129_col
        in
        fun132_dotprod (arg124_b_cols) (arg126_b) (arg125_a) (arg122_innerDim) (0.0) (0) (var130_a_start_offset) (var131_b_start_offset)
    in
    let rec fun152_dotprod arg159_outerDim arg158_a arg157_innerDim arg153_acc arg154_p arg155_aT_offset arg156_a_offset =
            if ( = ) (arg154_p) (arg157_innerDim) then
                arg153_acc
            else
                fun152_dotprod (arg159_outerDim) (arg158_a) (arg157_innerDim) (( +. ) (arg153_acc) (( *. ) (Array.get (arg158_a) (arg155_aT_offset)) (Array.get (arg158_a) (arg156_a_offset)))) (( + ) (arg154_p) (1)) (( + ) (arg155_aT_offset) (arg159_outerDim)) (( + ) (arg156_a_offset) (arg159_outerDim))
    in
    let fun160_matrixATAfWorker arg142_rows arg143_cols arg144_a arg145_idx =
        let var146_innerDim  =
            arg142_rows
        in
        let var147_outerDim  =
            arg143_cols
        in
        let var148_row  =
            ( / ) (arg145_idx) (arg143_cols)
        in
        let var149_col  =
            ( mod ) (arg145_idx) (arg143_cols)
        in
        let var150_aT_start_offset  =
            var148_row
        in
        let var151_a_start_offset  =
            var149_col
        in
        fun152_dotprod (var147_outerDim) (arg144_a) (var146_innerDim) (0.0) (0) (var150_aT_start_offset) (var151_a_start_offset)
    in
    let rec fun172_dotprodTransposeLhs arg181_b_cols arg180_a_cols arg179_b arg178_a arg177_b_rows arg173_acc arg174_p arg175_aT_offset arg176_b_offset =
            if ( = ) (arg174_p) (arg177_b_rows) then
                arg173_acc
            else
                fun172_dotprodTransposeLhs (arg181_b_cols) (arg180_a_cols) (arg179_b) (arg178_a) (arg177_b_rows) (( +. ) (arg173_acc) (( *. ) (Array.get (arg178_a) (arg175_aT_offset)) (Array.get (arg179_b) (arg176_b_offset)))) (( + ) (arg174_p) (1)) (( + ) (arg175_aT_offset) (arg180_a_cols)) (( + ) (arg176_b_offset) (arg181_b_cols))
    in
    let fun182_matrixMulTransposeLhsfWorker arg161_a_rows arg162_a_cols arg163_b_rows arg164_b_cols arg165_a arg166_b arg167_idx =
        let var168_row  =
            ( / ) (arg167_idx) (arg164_b_cols)
        in
        let var169_col  =
            ( mod ) (arg167_idx) (arg164_b_cols)
        in
        let var170_aT_start_offset  =
            var168_row
        in
        let var171_b_start_offset  =
            var169_col
        in
        fun172_dotprodTransposeLhs (arg164_b_cols) (arg162_a_cols) (arg166_b) (arg165_a) (arg163_b_rows) (0.0) (0) (var170_aT_start_offset) (var171_b_start_offset)
    in
    let fun195_gerWorkerf arg185_rows arg186_cols arg187_x arg188_y arg189_i arg190_Aval =
        let var191_row  =
            ( / ) (arg189_i) (arg186_cols)
        in
        let var192_col  =
            ( mod ) (arg189_i) (arg186_cols)
        in
        let var193_xval  =
            Array.get (arg187_x) (var191_row)
        in
        let var194_yval  =
            Array.get (arg188_y) (var192_col)
        in
        ( +. ) (( *. ) (var193_xval) (var194_yval)) (arg190_Aval)
    in
    let fun198_matAinitfun_v2 arg196_row arg197_col =
        ( -. ) (( /. ) (float_of_int (( + ) (( * ) (arg196_row) (arg196_row)) (arg197_col))) (3.0e+0)) (1.400000e-2)
    in
    let fun201_vecXinitfun arg199_row arg200_col =
        float_of_int (( mod ) (( * ) (arg199_row) (10657)) (41081))
    in
    let fun204_vecYinitfun arg202_row arg203_col =
        float_of_int (( mod ) (( * ) (arg202_row) (58437)) (84391))
    in
    let fun221_bm_runonce arg218_matA arg217_vecY arg216_vecX arg215_matA_cols arg214_matA_rows arg212__ =
        let var213_bm_t_start  =
            Unix.gettimeofday (())
        in
        let var219_matxyA  =
            gpuhost_fun195_gerWorkerf [|1; arg214_matA_rows; arg215_matA_cols|] [||] (arg216_vecX) (arg217_vecY) (arg218_matA)
        in
        let var220_bm_t_end  =
            Unix.gettimeofday (())
        in
        ( -. ) (var220_bm_t_end) (var213_bm_t_start)
    in
    let rec fun223_bm_iter arg232_matA_rows arg231_matA_cols arg230_vecX arg229_vecY arg228_matA arg226_n arg224_i arg225_acc =
            if ( >= ) (arg224_i) (arg226_n) then
                arg225_acc
            else
                let var227__  =
                    ()
                in
                let var233_res  =
                    fun221_bm_runonce (arg228_matA) (arg229_vecY) (arg230_vecX) (arg231_matA_cols) (arg232_matA_rows) (())
                in
                let var234_newacc  =
                    Array.append (arg225_acc) ([|var233_res|])
                in
                fun223_bm_iter (arg232_matA_rows) (arg231_matA_cols) (arg230_vecX) (arg229_vecY) (arg228_matA) (arg226_n) (( + ) (arg224_i) (1)) (var234_newacc)
    in
    let fun240_bm_runmultiple arg239_matA arg238_vecY arg237_vecX arg236_matA_cols arg235_matA_rows arg222_n =
        fun223_bm_iter (arg235_matA_rows) (arg236_matA_cols) (arg237_vecX) (arg238_vecY) (arg239_matA) (arg222_n) (0) ([||])
    in
    let rec fun243_quicksort_rec arg245_pivot arg246_lt_pivot arg247_geq_pivot arg248_remaining =
            if ( = ) (Array.length (arg248_remaining)) (0) then
                let var249_seq_lt  =
                    fun244_quicksort (arg246_lt_pivot)
                in
                let var250_seq_pivot  =
                    [|arg245_pivot|]
                in
                let var251_seq_geq  =
                    fun244_quicksort (arg247_geq_pivot)
                in
                Array.append (Array.append (var249_seq_lt) (var250_seq_pivot)) (var251_seq_geq)
            else
                let var252_e  =
                    fun1_head (arg248_remaining)
                in
                let var253_t  =
                    fun3_tail (arg248_remaining)
                in
                if ( < ) (var252_e) (arg245_pivot) then
                    fun243_quicksort_rec (arg245_pivot) ((fun x xs -> Array.append [|x|] xs) (var252_e) (arg246_lt_pivot)) (arg247_geq_pivot) (var253_t)
                else
                    fun243_quicksort_rec (arg245_pivot) (arg246_lt_pivot) ((fun x xs -> Array.append [|x|] xs) (var252_e) (arg247_geq_pivot)) (var253_t)
        and fun244_quicksort arg254_arr =
            if ( <= ) (Array.length (arg254_arr)) (1) then
                arg254_arr
            else
                fun243_quicksort_rec (fun1_head (arg254_arr)) ([||]) ([||]) (fun3_tail (arg254_arr))
    in
    let fun255_bm_sort arg241_arr =
        let var242_n  =
            Array.length (arg241_arr)
        in
        fun244_quicksort (arg241_arr)
    in
    let fun259_bm_median arg256_arr =
        let var257_n  =
            Array.length (arg256_arr)
        in
        let var258_sorted  =
            fun255_bm_sort (arg256_arr)
        in
        if ( = ) (( mod ) (var257_n) (2)) (0) then
            ( /. ) (( +. ) (Array.get (arg256_arr) (( - ) (( / ) (var257_n) (2)) (1))) (Array.get (arg256_arr) (( / ) (var257_n) (2)))) (2.0e+0)
        else
            Array.get (arg256_arr) (( / ) (var257_n) (2))
    in
    let rec fun262_work arg266_arr arg265_n arg263_i arg264_acc =
            if ( = ) (arg263_i) (arg265_n) then
                arg264_acc
            else
                fun262_work (arg266_arr) (arg265_n) (( + ) (arg263_i) (1)) (( +. ) (arg264_acc) (Array.get (arg266_arr) (arg263_i)))
    in
    let fun267_bm_sum arg260_arr =
        let var261_n  =
            Array.length (arg260_arr)
        in
        fun262_work (arg260_arr) (var261_n) (0) (0.0)
    in
    let rec fun270_work arg274_arr arg273_n arg271_i arg272_acc =
            if ( = ) (arg271_i) (arg273_n) then
                arg272_acc
            else
                let var275_e  =
                    Array.get (arg274_arr) (arg271_i)
                in
                fun270_work (arg274_arr) (arg273_n) (( + ) (arg271_i) (1)) (if ( > ) (var275_e) (arg272_acc) then
                    var275_e
                else
                    arg272_acc)
    in
    let fun276_bm_max arg268_arr =
        let var269_n  =
            Array.length (arg268_arr)
        in
        fun270_work (arg268_arr) (var269_n) (1) (Array.get (arg268_arr) (0))
    in
    let rec fun279_work arg283_arr arg282_n arg280_i arg281_acc =
            if ( = ) (arg280_i) (arg282_n) then
                arg281_acc
            else
                let var284_e  =
                    Array.get (arg283_arr) (arg280_i)
                in
                fun279_work (arg283_arr) (arg282_n) (( + ) (arg280_i) (1)) (if ( < ) (var284_e) (arg281_acc) then
                    var284_e
                else
                    arg281_acc)
    in
    let fun285_bm_min arg277_arr =
        let var278_n  =
            Array.length (arg277_arr)
        in
        fun279_work (arg277_arr) (var278_n) (1) (Array.get (arg277_arr) (0))
    in
    let rec fun290_work arg296_avg_co arg294_arr arg293_n arg291_i arg292_acc =
            if ( = ) (arg291_i) (arg293_n) then
                arg292_acc
            else
                let var295_elem  =
                    ( *. ) (Array.get (arg294_arr) (arg291_i)) (1.0e+3)
                in
                let var297_subres  =
                    ( -. ) (arg296_avg_co) (var295_elem)
                in
                fun290_work (arg296_avg_co) (arg294_arr) (arg293_n) (( + ) (arg291_i) (1)) (( +. ) (arg292_acc) (( *. ) (var297_subres) (var297_subres)))
    in
    let fun301_bm_variance arg286_avg arg287_arr =
        let var288_n  =
            Array.length (arg287_arr)
        in
        let var289_avg_co  =
            ( *. ) (arg286_avg) (1.0e+3)
        in
        let var298_elem  =
            ( *. ) (Array.get (arg287_arr) (0)) (1.0e+3)
        in
        let var299_subres  =
            ( -. ) (var289_avg_co) (var298_elem)
        in
        let var300_res  =
            fun290_work (var289_avg_co) (arg287_arr) (var288_n) (1) (( *. ) (var299_subres) (var299_subres))
        in
        ( /. ) (var300_res) (float_of_int (( - ) (var288_n) (1)))
    in
    let rec fun304_work arg308_arr arg306_n arg305_i =
            if ( = ) (arg305_i) (arg306_n) then
                ()
            else
                let var307__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|','; ' '|])
                in
                let var309__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg308_arr) (arg305_i)) (1.0e+3)))
                in
                fun304_work (arg308_arr) (arg306_n) (( + ) (arg305_i) (1))
    in
    let fun313_bm_printarr arg302_arr =
        let var303_n  =
            Array.length (arg302_arr)
        in
        let var310__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['|])
        in
        let var311__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg302_arr) (0)) (1.0e+3)))
        in
        let var312__  =
            fun304_work (arg302_arr) (var303_n) (1)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|']'|])
    in
    let fun316_bm_dist arg314_a arg315_b =
        if ( > ) (arg314_a) (arg315_b) then
            ( -. ) (arg314_a) (arg315_b)
        else
            ( -. ) (arg315_b) (arg314_a)
    in
    let var183_matA_rows  =
        8192
    in
    let var184_matA_cols  =
        8192
    in
    let var205_matA  =
        fun96_matrixInitf (var183_matA_rows) (var184_matA_cols) (fun198_matAinitfun_v2)
    in
    let var206_vecX_rows  =
        var184_matA_cols
    in
    let var207_vecX_cols  =
        1
    in
    let var208_vecY_rows  =
        var184_matA_cols
    in
    let var209_vecY_cols  =
        1
    in
    let var210_vecX  =
        fun96_matrixInitf (var206_vecX_rows) (var207_vecX_cols) (fun201_vecXinitfun)
    in
    let var211_vecY  =
        fun96_matrixInitf (var208_vecY_rows) (var209_vecY_cols) (fun204_vecYinitfun)
    in
    let var317__  =
        ()
    in
    let var318_bmres_warmup  =
        fun240_bm_runmultiple (var205_matA) (var211_vecY) (var210_vecX) (var184_matA_cols) (var183_matA_rows) (4)
    in
    let var319__  =
        ()
    in
    let var320_bmres_iters  =
        fun240_bm_runmultiple (var205_matA) (var211_vecY) (var210_vecX) (var184_matA_cols) (var183_matA_rows) (15)
    in
    let var387__  =
        let var321_median  =
            fun259_bm_median (var320_bmres_iters)
        in
        let var322_sum  =
            fun267_bm_sum (var320_bmres_iters)
        in
        let var323_avg  =
            ( /. ) (var322_sum) (1.50e+1)
        in
        let var324_max  =
            fun276_bm_max (var320_bmres_iters)
        in
        let var325_min  =
            fun285_bm_min (var320_bmres_iters)
        in
        let var326_variance  =
            fun301_bm_variance (var323_avg) (var320_bmres_iters)
        in
        let var327_median  =
            ( *. ) (var321_median) (1.0e+3)
        in
        let var328_sum  =
            ( *. ) (var322_sum) (1.0e+3)
        in
        let var329_avg  =
            ( *. ) (var323_avg) (1.0e+3)
        in
        let var330_max  =
            ( *. ) (var324_max) (1.0e+3)
        in
        let var331_min  =
            ( *. ) (var325_min) (1.0e+3)
        in
        let var332__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var333__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var334__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'1'; '5'|])
        in
        let var335__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var336__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var337__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var327_median))
        in
        let var338__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var339__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var340__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var330_max))
        in
        let var341__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var342__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var343__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var331_min))
        in
        let var344__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var345__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var346__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var329_avg))
        in
        let var347__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var348__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var349__  =
            fun313_bm_printarr (var320_bmres_iters)
        in
        let var350__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var351__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var352__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var326_variance))
        in
        let var353__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var354_median  =
            fun259_bm_median (var318_bmres_warmup)
        in
        let var355_sum  =
            fun267_bm_sum (var318_bmres_warmup)
        in
        let var356_avg  =
            ( /. ) (var355_sum) (4.0e+0)
        in
        let var357_max  =
            fun276_bm_max (var318_bmres_warmup)
        in
        let var358_min  =
            fun285_bm_min (var318_bmres_warmup)
        in
        let var359_variance  =
            fun301_bm_variance (var356_avg) (var318_bmres_warmup)
        in
        let var360_median  =
            ( *. ) (var354_median) (1.0e+3)
        in
        let var361_sum  =
            ( *. ) (var355_sum) (1.0e+3)
        in
        let var362_avg  =
            ( *. ) (var356_avg) (1.0e+3)
        in
        let var363_max  =
            ( *. ) (var357_max) (1.0e+3)
        in
        let var364_min  =
            ( *. ) (var358_min) (1.0e+3)
        in
        let var365__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'; '\n'; '['; 'w'; 'a'; 'r'; 'm'; 'u'; 'p'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var366__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var367__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'4'|])
        in
        let var368__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var369__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var370__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var360_median))
        in
        let var371__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var372__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var373__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var363_max))
        in
        let var374__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var375__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var376__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var364_min))
        in
        let var377__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var378__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var379__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var362_avg))
        in
        let var380__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var381__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var382__  =
            fun313_bm_printarr (var318_bmres_warmup)
        in
        let var383__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var384__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var385__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var359_variance))
        in
        let var386__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        ()
    in
    ()