open Printf



let main =
    let fun1_head arg0_s =
        Array.get (arg0_s) (0)
    in
    let fun3_tail arg2_s =
        (fun xs start len -> Array.sub xs (min ((Array.length xs) - 1) start) (min ((Array.length xs) - start) len)) (arg2_s) (1) (Array.length (arg2_s))
    in
    let fun5_null arg4_l =
        ( = ) (Array.length (arg4_l)) (0)
    in
    let fun8_map arg6_f arg7_seq =
        Array.map (arg6_f) (arg7_seq)
    in
    let fun11_mapi arg9_f arg10_seq =
        Array.mapi (arg9_f) (arg10_seq)
    in
    let fun14_seqInit arg12_size arg13_f =
        Array.init (arg12_size) (arg13_f)
    in
    let rec fun16_int2string_rechelper arg17_n =
            if ( < ) (arg17_n) (10) then
                [|char_of_int (( + ) (arg17_n) (int_of_char ('0')))|]
            else
                let var18_d  =
                    [|char_of_int (( + ) (( mod ) (arg17_n) (10)) (int_of_char ('0')))|]
                in
                Array.append (fun16_int2string_rechelper (( / ) (arg17_n) (10))) (var18_d)
    in
    let fun19_int2string arg15_n =
        if ( < ) (arg15_n) (0) then
            (fun x xs -> Array.append [|x|] xs) ('-') (fun16_int2string_rechelper (( ~- ) (arg15_n)))
        else
            fun16_int2string_rechelper (arg15_n)
    in
    let fun21_float2string arg20_f =
        Array.of_seq (String.to_seq (string_of_float (arg20_f)))
    in
    let rec fun22_strJoin arg23_delim arg24_strs =
            if ( = ) (Array.length (arg24_strs)) (0) then
                [||]
            else
                if ( = ) (Array.length (arg24_strs)) (1) then
                    fun1_head (arg24_strs)
                else
                    Array.append (Array.append (fun1_head (arg24_strs)) (arg23_delim)) (fun22_strJoin (arg23_delim) (fun3_tail (arg24_strs)))
    in
    let fun26_printint arg25_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg25_i))
    in
    let fun28_printintln arg27_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (Array.append (fun19_int2string (arg27_i)) ([|'\n'|]))
    in
    let rec fun31_printloop arg33_arr arg32_i =
            if ( = ) (arg32_i) (Array.length (arg33_arr)) then
                ()
            else
                let var34__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var35__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg32_i))
                in
                let var36__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var37__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg33_arr) (arg32_i)))
                in
                let var38__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun31_printloop (arg33_arr) (( + ) (arg32_i) (1))
    in
    let fun42_printintarr arg29_name arg30_arr =
        let var39__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var40__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg29_name)
        in
        let var41__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun31_printloop (arg30_arr) (0)
    in
    let rec fun45_printloop arg47_arr arg46_i =
            if ( = ) (arg46_i) (Array.length (arg47_arr)) then
                ()
            else
                let var48__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var49__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg46_i))
                in
                let var50__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var51__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg47_arr) (arg46_i)))
                in
                let var52__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun45_printloop (arg47_arr) (( + ) (arg46_i) (1))
    in
    let fun56_printfloatarr arg43_name arg44_arr =
        let var53__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var54__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg43_name)
        in
        let var55__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun45_printloop (arg44_arr) (0)
    in
    let rec fun59_printloop arg62_vec arg61_size arg60_i =
            if ( = ) (arg60_i) (arg61_size) then
                ()
            else
                let var63__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg62_vec) (arg60_i)))
                in
                let var64__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun59_printloop (arg62_vec) (arg61_size) (( + ) (arg60_i) (1))
    in
    let fun66_printSeqi arg57_size arg58_vec =
        let var65__  =
            fun59_printloop (arg58_vec) (arg57_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let rec fun69_printloop arg72_vec arg71_size arg70_i =
            if ( = ) (arg70_i) (arg71_size) then
                ()
            else
                let var73__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg72_vec) (arg70_i)))
                in
                let var74__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun69_printloop (arg72_vec) (arg71_size) (( + ) (arg70_i) (1))
    in
    let fun76_printSeqf arg67_size arg68_vec =
        let var75__  =
            fun69_printloop (arg68_vec) (arg67_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let fun80_matrixMkf arg77_rows arg78_cols arg79_v =
        Array.make (( * ) (arg77_rows) (arg78_cols)) (arg79_v)
    in
    let fun86_matrixGetf arg81_row arg82_col arg83_m_rows arg84_m_cols arg85_m =
        Array.get (arg85_m) (( + ) (( * ) (arg84_m_cols) (arg81_row)) (arg82_col))
    in
    let fun95_seqInitFun arg94_f arg91_cols arg90_i =
        let var92_row  =
            ( / ) (arg90_i) (arg91_cols)
        in
        let var93_col  =
            ( mod ) (arg90_i) (arg91_cols)
        in
        arg94_f (var92_row) (var93_col)
    in
    let fun96_matrixInitf arg87_rows arg88_cols arg89_f =
        fun14_seqInit (( * ) (arg87_rows) (arg88_cols)) (fun95_seqInitFun (arg89_f) (arg88_cols))
    in
    let rec fun100_printrc arg107_m arg104_m_cols arg103_m_rows arg101_row arg102_col =
            if ( = ) (arg101_row) (arg103_m_rows) then
                [||]
            else
                let var105_next_col  =
                    ( mod ) (( + ) (arg102_col) (1)) (arg104_m_cols)
                in
                let var106_next_row  =
                    if ( = ) (var105_next_col) (0) then
                        ( + ) (arg101_row) (1)
                    else
                        arg101_row
                in
                fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg101_row) (arg102_col) (arg103_m_rows) (arg104_m_cols) (arg107_m)); if ( = ) (var105_next_col) (0) then
                    [|'\n'|]
                else
                    [|' '|]; fun100_printrc (arg107_m) (arg104_m_cols) (arg103_m_rows) (var106_next_row) (var105_next_col)|])
    in
    let fun108_matrix2strf arg97_m_rows arg98_m_cols arg99_m =
        fun100_printrc (arg99_m) (arg98_m_cols) (arg97_m_rows) (0) (0)
    in
    let rec fun112_printrc arg119_m arg116_m_cols arg115_m_rows arg113_row arg114_col =
            if ( = ) (arg113_row) (arg115_m_rows) then
                [||]
            else
                let var117_next_col  =
                    ( mod ) (( + ) (arg114_col) (1)) (arg116_m_cols)
                in
                let var118_next_row  =
                    if ( = ) (var117_next_col) (0) then
                        ( + ) (arg113_row) (1)
                    else
                        arg113_row
                in
                let var120__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg113_row) (arg114_col) (arg115_m_rows) (arg116_m_cols) (arg119_m)); if ( = ) (var117_next_col) (0) then
                        [|'\n'|]
                    else
                        [|' '|]|]))
                in
                fun112_printrc (arg119_m) (arg116_m_cols) (arg115_m_rows) (var118_next_row) (var117_next_col)
    in
    let fun121_printMatrixf arg109_m_rows arg110_m_cols arg111_m =
        fun112_printrc (arg111_m) (arg110_m_cols) (arg109_m_rows) (0) (0)
    in
    let rec fun132_dotprod arg140_b_cols arg139_b arg138_a arg137_innerDim arg133_acc arg134_p arg135_a_offset arg136_b_offset =
            if ( = ) (arg134_p) (arg137_innerDim) then
                arg133_acc
            else
                fun132_dotprod (arg140_b_cols) (arg139_b) (arg138_a) (arg137_innerDim) (( +. ) (arg133_acc) (( *. ) (Array.get (arg138_a) (arg135_a_offset)) (Array.get (arg139_b) (arg136_b_offset)))) (( + ) (arg134_p) (1)) (( + ) (arg135_a_offset) (1)) (( + ) (arg136_b_offset) (arg140_b_cols))
    in
    let fun141_matrixMulfWorker arg122_innerDim arg123_a_rows arg124_b_cols arg125_a arg126_b arg127_idx =
        let var128_row  =
            ( / ) (arg127_idx) (arg124_b_cols)
        in
        let var129_col  =
            ( mod ) (arg127_idx) (arg124_b_cols)
        in
        let var130_a_start_offset  =
            ( * ) (arg122_innerDim) (var128_row)
        in
        let var131_b_start_offset  =
            var129_col
        in
        fun132_dotprod (arg124_b_cols) (arg126_b) (arg125_a) (arg122_innerDim) (0.0) (0) (var130_a_start_offset) (var131_b_start_offset)
    in
    let rec fun152_dotprod arg159_outerDim arg158_a arg157_innerDim arg153_acc arg154_p arg155_aT_offset arg156_a_offset =
            if ( = ) (arg154_p) (arg157_innerDim) then
                arg153_acc
            else
                fun152_dotprod (arg159_outerDim) (arg158_a) (arg157_innerDim) (( +. ) (arg153_acc) (( *. ) (Array.get (arg158_a) (arg155_aT_offset)) (Array.get (arg158_a) (arg156_a_offset)))) (( + ) (arg154_p) (1)) (( + ) (arg155_aT_offset) (arg159_outerDim)) (( + ) (arg156_a_offset) (arg159_outerDim))
    in
    let fun160_matrixATAfWorker arg142_rows arg143_cols arg144_a arg145_idx =
        let var146_innerDim  =
            arg142_rows
        in
        let var147_outerDim  =
            arg143_cols
        in
        let var148_row  =
            ( / ) (arg145_idx) (arg143_cols)
        in
        let var149_col  =
            ( mod ) (arg145_idx) (arg143_cols)
        in
        let var150_aT_start_offset  =
            var148_row
        in
        let var151_a_start_offset  =
            var149_col
        in
        fun152_dotprod (var147_outerDim) (arg144_a) (var146_innerDim) (0.0) (0) (var150_aT_start_offset) (var151_a_start_offset)
    in
    let rec fun172_dotprodTransposeLhs arg181_b_cols arg180_a_cols arg179_b arg178_a arg177_b_rows arg173_acc arg174_p arg175_aT_offset arg176_b_offset =
            if ( = ) (arg174_p) (arg177_b_rows) then
                arg173_acc
            else
                fun172_dotprodTransposeLhs (arg181_b_cols) (arg180_a_cols) (arg179_b) (arg178_a) (arg177_b_rows) (( +. ) (arg173_acc) (( *. ) (Array.get (arg178_a) (arg175_aT_offset)) (Array.get (arg179_b) (arg176_b_offset)))) (( + ) (arg174_p) (1)) (( + ) (arg175_aT_offset) (arg180_a_cols)) (( + ) (arg176_b_offset) (arg181_b_cols))
    in
    let fun182_matrixMulTransposeLhsfWorker arg161_a_rows arg162_a_cols arg163_b_rows arg164_b_cols arg165_a arg166_b arg167_idx =
        let var168_row  =
            ( / ) (arg167_idx) (arg164_b_cols)
        in
        let var169_col  =
            ( mod ) (arg167_idx) (arg164_b_cols)
        in
        let var170_aT_start_offset  =
            var168_row
        in
        let var171_b_start_offset  =
            var169_col
        in
        fun172_dotprodTransposeLhs (arg164_b_cols) (arg162_a_cols) (arg166_b) (arg165_a) (arg163_b_rows) (0.0) (0) (var170_aT_start_offset) (var171_b_start_offset)
    in
    let fun187_matAinitfun_v2 arg185_row arg186_col =
        ( -. ) (( /. ) (float_of_int (( + ) (( * ) (arg185_row) (arg185_row)) (arg186_col))) (3.0e+0)) (1.400000e-2)
    in
    let fun190_vecXinitfun arg188_row arg189_col =
        float_of_int (( mod ) (( * ) (arg188_row) (10657)) (41081))
    in
    let fun204_bm_runonce arg201_vecX arg200_matA arg199_matA_rows arg198_vecX_cols arg197_matA_cols arg195__ =
        let var196_bm_t_start  =
            Unix.gettimeofday (())
        in
        let var202_vecAx  =
            fun14_seqInit (( * ) (arg197_matA_cols) (arg198_vecX_cols)) (fun141_matrixMulfWorker (arg197_matA_cols) (arg199_matA_rows) (arg198_vecX_cols) (arg200_matA) (arg201_vecX))
        in
        let var203_bm_t_end  =
            Unix.gettimeofday (())
        in
        ( -. ) (var203_bm_t_end) (var196_bm_t_start)
    in
    let rec fun206_bm_iter arg215_matA_cols arg214_vecX_cols arg213_matA_rows arg212_matA arg211_vecX arg209_n arg207_i arg208_acc =
            if ( >= ) (arg207_i) (arg209_n) then
                arg208_acc
            else
                let var210__  =
                    ()
                in
                let var216_res  =
                    fun204_bm_runonce (arg211_vecX) (arg212_matA) (arg213_matA_rows) (arg214_vecX_cols) (arg215_matA_cols) (())
                in
                let var217_newacc  =
                    Array.append (arg208_acc) ([|var216_res|])
                in
                fun206_bm_iter (arg215_matA_cols) (arg214_vecX_cols) (arg213_matA_rows) (arg212_matA) (arg211_vecX) (arg209_n) (( + ) (arg207_i) (1)) (var217_newacc)
    in
    let fun223_bm_runmultiple arg222_vecX arg221_matA arg220_matA_rows arg219_vecX_cols arg218_matA_cols arg205_n =
        fun206_bm_iter (arg218_matA_cols) (arg219_vecX_cols) (arg220_matA_rows) (arg221_matA) (arg222_vecX) (arg205_n) (0) ([||])
    in
    let rec fun226_quicksort_rec arg228_pivot arg229_lt_pivot arg230_geq_pivot arg231_remaining =
            if ( = ) (Array.length (arg231_remaining)) (0) then
                let var232_seq_lt  =
                    fun227_quicksort (arg229_lt_pivot)
                in
                let var233_seq_pivot  =
                    [|arg228_pivot|]
                in
                let var234_seq_geq  =
                    fun227_quicksort (arg230_geq_pivot)
                in
                Array.append (Array.append (var232_seq_lt) (var233_seq_pivot)) (var234_seq_geq)
            else
                let var235_e  =
                    fun1_head (arg231_remaining)
                in
                let var236_t  =
                    fun3_tail (arg231_remaining)
                in
                if ( < ) (var235_e) (arg228_pivot) then
                    fun226_quicksort_rec (arg228_pivot) ((fun x xs -> Array.append [|x|] xs) (var235_e) (arg229_lt_pivot)) (arg230_geq_pivot) (var236_t)
                else
                    fun226_quicksort_rec (arg228_pivot) (arg229_lt_pivot) ((fun x xs -> Array.append [|x|] xs) (var235_e) (arg230_geq_pivot)) (var236_t)
        and fun227_quicksort arg237_arr =
            if ( <= ) (Array.length (arg237_arr)) (1) then
                arg237_arr
            else
                fun226_quicksort_rec (fun1_head (arg237_arr)) ([||]) ([||]) (fun3_tail (arg237_arr))
    in
    let fun238_bm_sort arg224_arr =
        let var225_n  =
            Array.length (arg224_arr)
        in
        fun227_quicksort (arg224_arr)
    in
    let fun242_bm_median arg239_arr =
        let var240_n  =
            Array.length (arg239_arr)
        in
        let var241_sorted  =
            fun238_bm_sort (arg239_arr)
        in
        if ( = ) (( mod ) (var240_n) (2)) (0) then
            ( /. ) (( +. ) (Array.get (arg239_arr) (( - ) (( / ) (var240_n) (2)) (1))) (Array.get (arg239_arr) (( / ) (var240_n) (2)))) (2.0e+0)
        else
            Array.get (arg239_arr) (( / ) (var240_n) (2))
    in
    let rec fun245_work arg249_arr arg248_n arg246_i arg247_acc =
            if ( = ) (arg246_i) (arg248_n) then
                arg247_acc
            else
                fun245_work (arg249_arr) (arg248_n) (( + ) (arg246_i) (1)) (( +. ) (arg247_acc) (Array.get (arg249_arr) (arg246_i)))
    in
    let fun250_bm_sum arg243_arr =
        let var244_n  =
            Array.length (arg243_arr)
        in
        fun245_work (arg243_arr) (var244_n) (0) (0.0)
    in
    let rec fun253_work arg257_arr arg256_n arg254_i arg255_acc =
            if ( = ) (arg254_i) (arg256_n) then
                arg255_acc
            else
                let var258_e  =
                    Array.get (arg257_arr) (arg254_i)
                in
                fun253_work (arg257_arr) (arg256_n) (( + ) (arg254_i) (1)) (if ( > ) (var258_e) (arg255_acc) then
                    var258_e
                else
                    arg255_acc)
    in
    let fun259_bm_max arg251_arr =
        let var252_n  =
            Array.length (arg251_arr)
        in
        fun253_work (arg251_arr) (var252_n) (1) (Array.get (arg251_arr) (0))
    in
    let rec fun262_work arg266_arr arg265_n arg263_i arg264_acc =
            if ( = ) (arg263_i) (arg265_n) then
                arg264_acc
            else
                let var267_e  =
                    Array.get (arg266_arr) (arg263_i)
                in
                fun262_work (arg266_arr) (arg265_n) (( + ) (arg263_i) (1)) (if ( < ) (var267_e) (arg264_acc) then
                    var267_e
                else
                    arg264_acc)
    in
    let fun268_bm_min arg260_arr =
        let var261_n  =
            Array.length (arg260_arr)
        in
        fun262_work (arg260_arr) (var261_n) (1) (Array.get (arg260_arr) (0))
    in
    let rec fun273_work arg279_avg_co arg277_arr arg276_n arg274_i arg275_acc =
            if ( = ) (arg274_i) (arg276_n) then
                arg275_acc
            else
                let var278_elem  =
                    ( *. ) (Array.get (arg277_arr) (arg274_i)) (1.0e+3)
                in
                let var280_subres  =
                    ( -. ) (arg279_avg_co) (var278_elem)
                in
                fun273_work (arg279_avg_co) (arg277_arr) (arg276_n) (( + ) (arg274_i) (1)) (( +. ) (arg275_acc) (( *. ) (var280_subres) (var280_subres)))
    in
    let fun284_bm_variance arg269_avg arg270_arr =
        let var271_n  =
            Array.length (arg270_arr)
        in
        let var272_avg_co  =
            ( *. ) (arg269_avg) (1.0e+3)
        in
        let var281_elem  =
            ( *. ) (Array.get (arg270_arr) (0)) (1.0e+3)
        in
        let var282_subres  =
            ( -. ) (var272_avg_co) (var281_elem)
        in
        let var283_res  =
            fun273_work (var272_avg_co) (arg270_arr) (var271_n) (1) (( *. ) (var282_subres) (var282_subres))
        in
        ( /. ) (var283_res) (float_of_int (( - ) (var271_n) (1)))
    in
    let rec fun287_work arg291_arr arg289_n arg288_i =
            if ( = ) (arg288_i) (arg289_n) then
                ()
            else
                let var290__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|','; ' '|])
                in
                let var292__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg291_arr) (arg288_i)) (1.0e+3)))
                in
                fun287_work (arg291_arr) (arg289_n) (( + ) (arg288_i) (1))
    in
    let fun296_bm_printarr arg285_arr =
        let var286_n  =
            Array.length (arg285_arr)
        in
        let var293__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['|])
        in
        let var294__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg285_arr) (0)) (1.0e+3)))
        in
        let var295__  =
            fun287_work (arg285_arr) (var286_n) (1)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|']'|])
    in
    let fun299_bm_dist arg297_a arg298_b =
        if ( > ) (arg297_a) (arg298_b) then
            ( -. ) (arg297_a) (arg298_b)
        else
            ( -. ) (arg298_b) (arg297_a)
    in
    let var183_matA_rows  =
        256
    in
    let var184_matA_cols  =
        256
    in
    let var191_matA  =
        fun96_matrixInitf (var183_matA_rows) (var184_matA_cols) (fun187_matAinitfun_v2)
    in
    let var192_vecX_rows  =
        var184_matA_cols
    in
    let var193_vecX_cols  =
        1
    in
    let var194_vecX  =
        fun96_matrixInitf (var192_vecX_rows) (var193_vecX_cols) (fun190_vecXinitfun)
    in
    let var300__  =
        ()
    in
    let var301_bmres_warmup  =
        fun223_bm_runmultiple (var194_vecX) (var191_matA) (var183_matA_rows) (var193_vecX_cols) (var184_matA_cols) (4)
    in
    let var302__  =
        ()
    in
    let var303_bmres_iters  =
        fun223_bm_runmultiple (var194_vecX) (var191_matA) (var183_matA_rows) (var193_vecX_cols) (var184_matA_cols) (15)
    in
    let var370__  =
        let var304_median  =
            fun242_bm_median (var303_bmres_iters)
        in
        let var305_sum  =
            fun250_bm_sum (var303_bmres_iters)
        in
        let var306_avg  =
            ( /. ) (var305_sum) (1.50e+1)
        in
        let var307_max  =
            fun259_bm_max (var303_bmres_iters)
        in
        let var308_min  =
            fun268_bm_min (var303_bmres_iters)
        in
        let var309_variance  =
            fun284_bm_variance (var306_avg) (var303_bmres_iters)
        in
        let var310_median  =
            ( *. ) (var304_median) (1.0e+3)
        in
        let var311_sum  =
            ( *. ) (var305_sum) (1.0e+3)
        in
        let var312_avg  =
            ( *. ) (var306_avg) (1.0e+3)
        in
        let var313_max  =
            ( *. ) (var307_max) (1.0e+3)
        in
        let var314_min  =
            ( *. ) (var308_min) (1.0e+3)
        in
        let var315__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var316__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var317__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'1'; '5'|])
        in
        let var318__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var319__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var320__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var310_median))
        in
        let var321__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var322__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var323__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var313_max))
        in
        let var324__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var325__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var326__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var314_min))
        in
        let var327__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var328__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var329__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var312_avg))
        in
        let var330__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var331__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var332__  =
            fun296_bm_printarr (var303_bmres_iters)
        in
        let var333__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var334__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var335__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var309_variance))
        in
        let var336__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var337_median  =
            fun242_bm_median (var301_bmres_warmup)
        in
        let var338_sum  =
            fun250_bm_sum (var301_bmres_warmup)
        in
        let var339_avg  =
            ( /. ) (var338_sum) (4.0e+0)
        in
        let var340_max  =
            fun259_bm_max (var301_bmres_warmup)
        in
        let var341_min  =
            fun268_bm_min (var301_bmres_warmup)
        in
        let var342_variance  =
            fun284_bm_variance (var339_avg) (var301_bmres_warmup)
        in
        let var343_median  =
            ( *. ) (var337_median) (1.0e+3)
        in
        let var344_sum  =
            ( *. ) (var338_sum) (1.0e+3)
        in
        let var345_avg  =
            ( *. ) (var339_avg) (1.0e+3)
        in
        let var346_max  =
            ( *. ) (var340_max) (1.0e+3)
        in
        let var347_min  =
            ( *. ) (var341_min) (1.0e+3)
        in
        let var348__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'; '\n'; '['; 'w'; 'a'; 'r'; 'm'; 'u'; 'p'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var349__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var350__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'4'|])
        in
        let var351__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var352__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var353__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var343_median))
        in
        let var354__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var355__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var356__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var346_max))
        in
        let var357__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var358__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var359__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var347_min))
        in
        let var360__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var361__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var362__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var345_avg))
        in
        let var363__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var364__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var365__  =
            fun296_bm_printarr (var301_bmres_warmup)
        in
        let var366__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var367__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var368__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var342_variance))
        in
        let var369__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        ()
    in
    ()