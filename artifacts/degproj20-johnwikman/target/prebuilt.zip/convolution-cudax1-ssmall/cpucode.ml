open Printf

external gpuhost_fun208_convolute17Worker: int array -> float array -> float array -> float array -> float array = "gpuhost_fun208_convolute17Worker"

let main =
    let fun1_head arg0_s =
        Array.get (arg0_s) (0)
    in
    let fun3_tail arg2_s =
        (fun xs start len -> Array.sub xs (min ((Array.length xs) - 1) start) (min ((Array.length xs) - start) len)) (arg2_s) (1) (Array.length (arg2_s))
    in
    let fun5_null arg4_l =
        ( = ) (Array.length (arg4_l)) (0)
    in
    let fun8_map arg6_f arg7_seq =
        Array.map (arg6_f) (arg7_seq)
    in
    let fun11_mapi arg9_f arg10_seq =
        Array.mapi (arg9_f) (arg10_seq)
    in
    let fun14_seqInit arg12_size arg13_f =
        Array.init (arg12_size) (arg13_f)
    in
    let rec fun16_int2string_rechelper arg17_n =
            if ( < ) (arg17_n) (10) then
                [|char_of_int (( + ) (arg17_n) (int_of_char ('0')))|]
            else
                let var18_d  =
                    [|char_of_int (( + ) (( mod ) (arg17_n) (10)) (int_of_char ('0')))|]
                in
                Array.append (fun16_int2string_rechelper (( / ) (arg17_n) (10))) (var18_d)
    in
    let fun19_int2string arg15_n =
        if ( < ) (arg15_n) (0) then
            (fun x xs -> Array.append [|x|] xs) ('-') (fun16_int2string_rechelper (( ~- ) (arg15_n)))
        else
            fun16_int2string_rechelper (arg15_n)
    in
    let fun21_float2string arg20_f =
        Array.of_seq (String.to_seq (string_of_float (arg20_f)))
    in
    let rec fun22_strJoin arg23_delim arg24_strs =
            if ( = ) (Array.length (arg24_strs)) (0) then
                [||]
            else
                if ( = ) (Array.length (arg24_strs)) (1) then
                    fun1_head (arg24_strs)
                else
                    Array.append (Array.append (fun1_head (arg24_strs)) (arg23_delim)) (fun22_strJoin (arg23_delim) (fun3_tail (arg24_strs)))
    in
    let fun26_printint arg25_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg25_i))
    in
    let fun28_printintln arg27_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (Array.append (fun19_int2string (arg27_i)) ([|'\n'|]))
    in
    let rec fun31_printloop arg33_arr arg32_i =
            if ( = ) (arg32_i) (Array.length (arg33_arr)) then
                ()
            else
                let var34__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var35__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg32_i))
                in
                let var36__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var37__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg33_arr) (arg32_i)))
                in
                let var38__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun31_printloop (arg33_arr) (( + ) (arg32_i) (1))
    in
    let fun42_printintarr arg29_name arg30_arr =
        let var39__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var40__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg29_name)
        in
        let var41__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun31_printloop (arg30_arr) (0)
    in
    let rec fun45_printloop arg47_arr arg46_i =
            if ( = ) (arg46_i) (Array.length (arg47_arr)) then
                ()
            else
                let var48__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var49__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg46_i))
                in
                let var50__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var51__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg47_arr) (arg46_i)))
                in
                let var52__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun45_printloop (arg47_arr) (( + ) (arg46_i) (1))
    in
    let fun56_printfloatarr arg43_name arg44_arr =
        let var53__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var54__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg43_name)
        in
        let var55__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun45_printloop (arg44_arr) (0)
    in
    let rec fun59_printloop arg62_vec arg61_size arg60_i =
            if ( = ) (arg60_i) (arg61_size) then
                ()
            else
                let var63__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg62_vec) (arg60_i)))
                in
                let var64__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun59_printloop (arg62_vec) (arg61_size) (( + ) (arg60_i) (1))
    in
    let fun66_printSeqi arg57_size arg58_vec =
        let var65__  =
            fun59_printloop (arg58_vec) (arg57_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let rec fun69_printloop arg72_vec arg71_size arg70_i =
            if ( = ) (arg70_i) (arg71_size) then
                ()
            else
                let var73__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg72_vec) (arg70_i)))
                in
                let var74__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun69_printloop (arg72_vec) (arg71_size) (( + ) (arg70_i) (1))
    in
    let fun76_printSeqf arg67_size arg68_vec =
        let var75__  =
            fun69_printloop (arg68_vec) (arg67_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let fun80_matrixMkf arg77_rows arg78_cols arg79_v =
        Array.make (( * ) (arg77_rows) (arg78_cols)) (arg79_v)
    in
    let fun86_matrixGetf arg81_row arg82_col arg83_m_rows arg84_m_cols arg85_m =
        Array.get (arg85_m) (( + ) (( * ) (arg84_m_cols) (arg81_row)) (arg82_col))
    in
    let fun95_seqInitFun arg94_f arg91_cols arg90_i =
        let var92_row  =
            ( / ) (arg90_i) (arg91_cols)
        in
        let var93_col  =
            ( mod ) (arg90_i) (arg91_cols)
        in
        arg94_f (var92_row) (var93_col)
    in
    let fun96_matrixInitf arg87_rows arg88_cols arg89_f =
        fun14_seqInit (( * ) (arg87_rows) (arg88_cols)) (fun95_seqInitFun (arg89_f) (arg88_cols))
    in
    let rec fun100_printrc arg107_m arg104_m_cols arg103_m_rows arg101_row arg102_col =
            if ( = ) (arg101_row) (arg103_m_rows) then
                [||]
            else
                let var105_next_col  =
                    ( mod ) (( + ) (arg102_col) (1)) (arg104_m_cols)
                in
                let var106_next_row  =
                    if ( = ) (var105_next_col) (0) then
                        ( + ) (arg101_row) (1)
                    else
                        arg101_row
                in
                fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg101_row) (arg102_col) (arg103_m_rows) (arg104_m_cols) (arg107_m)); if ( = ) (var105_next_col) (0) then
                    [|'\n'|]
                else
                    [|' '|]; fun100_printrc (arg107_m) (arg104_m_cols) (arg103_m_rows) (var106_next_row) (var105_next_col)|])
    in
    let fun108_matrix2strf arg97_m_rows arg98_m_cols arg99_m =
        fun100_printrc (arg99_m) (arg98_m_cols) (arg97_m_rows) (0) (0)
    in
    let rec fun112_printrc arg119_m arg116_m_cols arg115_m_rows arg113_row arg114_col =
            if ( = ) (arg113_row) (arg115_m_rows) then
                [||]
            else
                let var117_next_col  =
                    ( mod ) (( + ) (arg114_col) (1)) (arg116_m_cols)
                in
                let var118_next_row  =
                    if ( = ) (var117_next_col) (0) then
                        ( + ) (arg113_row) (1)
                    else
                        arg113_row
                in
                let var120__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg113_row) (arg114_col) (arg115_m_rows) (arg116_m_cols) (arg119_m)); if ( = ) (var117_next_col) (0) then
                        [|'\n'|]
                    else
                        [|' '|]|]))
                in
                fun112_printrc (arg119_m) (arg116_m_cols) (arg115_m_rows) (var118_next_row) (var117_next_col)
    in
    let fun121_printMatrixf arg109_m_rows arg110_m_cols arg111_m =
        fun112_printrc (arg111_m) (arg110_m_cols) (arg109_m_rows) (0) (0)
    in
    let rec fun132_dotprod arg140_b_cols arg139_b arg138_a arg137_innerDim arg133_acc arg134_p arg135_a_offset arg136_b_offset =
            if ( = ) (arg134_p) (arg137_innerDim) then
                arg133_acc
            else
                fun132_dotprod (arg140_b_cols) (arg139_b) (arg138_a) (arg137_innerDim) (( +. ) (arg133_acc) (( *. ) (Array.get (arg138_a) (arg135_a_offset)) (Array.get (arg139_b) (arg136_b_offset)))) (( + ) (arg134_p) (1)) (( + ) (arg135_a_offset) (1)) (( + ) (arg136_b_offset) (arg140_b_cols))
    in
    let fun141_matrixMulfWorker arg122_innerDim arg123_a_rows arg124_b_cols arg125_a arg126_b arg127_idx =
        let var128_row  =
            ( / ) (arg127_idx) (arg124_b_cols)
        in
        let var129_col  =
            ( mod ) (arg127_idx) (arg124_b_cols)
        in
        let var130_a_start_offset  =
            ( * ) (arg122_innerDim) (var128_row)
        in
        let var131_b_start_offset  =
            var129_col
        in
        fun132_dotprod (arg124_b_cols) (arg126_b) (arg125_a) (arg122_innerDim) (0.0) (0) (var130_a_start_offset) (var131_b_start_offset)
    in
    let rec fun152_dotprod arg159_outerDim arg158_a arg157_innerDim arg153_acc arg154_p arg155_aT_offset arg156_a_offset =
            if ( = ) (arg154_p) (arg157_innerDim) then
                arg153_acc
            else
                fun152_dotprod (arg159_outerDim) (arg158_a) (arg157_innerDim) (( +. ) (arg153_acc) (( *. ) (Array.get (arg158_a) (arg155_aT_offset)) (Array.get (arg158_a) (arg156_a_offset)))) (( + ) (arg154_p) (1)) (( + ) (arg155_aT_offset) (arg159_outerDim)) (( + ) (arg156_a_offset) (arg159_outerDim))
    in
    let fun160_matrixATAfWorker arg142_rows arg143_cols arg144_a arg145_idx =
        let var146_innerDim  =
            arg142_rows
        in
        let var147_outerDim  =
            arg143_cols
        in
        let var148_row  =
            ( / ) (arg145_idx) (arg143_cols)
        in
        let var149_col  =
            ( mod ) (arg145_idx) (arg143_cols)
        in
        let var150_aT_start_offset  =
            var148_row
        in
        let var151_a_start_offset  =
            var149_col
        in
        fun152_dotprod (var147_outerDim) (arg144_a) (var146_innerDim) (0.0) (0) (var150_aT_start_offset) (var151_a_start_offset)
    in
    let rec fun172_dotprodTransposeLhs arg181_b_cols arg180_a_cols arg179_b arg178_a arg177_b_rows arg173_acc arg174_p arg175_aT_offset arg176_b_offset =
            if ( = ) (arg174_p) (arg177_b_rows) then
                arg173_acc
            else
                fun172_dotprodTransposeLhs (arg181_b_cols) (arg180_a_cols) (arg179_b) (arg178_a) (arg177_b_rows) (( +. ) (arg173_acc) (( *. ) (Array.get (arg178_a) (arg175_aT_offset)) (Array.get (arg179_b) (arg176_b_offset)))) (( + ) (arg174_p) (1)) (( + ) (arg175_aT_offset) (arg180_a_cols)) (( + ) (arg176_b_offset) (arg181_b_cols))
    in
    let fun182_matrixMulTransposeLhsfWorker arg161_a_rows arg162_a_cols arg163_b_rows arg164_b_cols arg165_a arg166_b arg167_idx =
        let var168_row  =
            ( / ) (arg167_idx) (arg164_b_cols)
        in
        let var169_col  =
            ( mod ) (arg167_idx) (arg164_b_cols)
        in
        let var170_aT_start_offset  =
            var168_row
        in
        let var171_b_start_offset  =
            var169_col
        in
        fun172_dotprodTransposeLhs (arg164_b_cols) (arg162_a_cols) (arg166_b) (arg165_a) (arg163_b_rows) (0.0) (0) (var170_aT_start_offset) (var171_b_start_offset)
    in
    let fun187_matAinitfun_v3 arg185_row arg186_col =
        ( -. ) (( /. ) (float_of_int (( mod ) (( * ) (arg185_row) (arg185_row)) (( + ) (arg186_col) (17)))) (3.991000e+0)) (1.400000e-2)
    in
    let fun189_filter17initfun arg188_i =
        ( -. ) (1.250e+0) (( /. ) (1.0e-0) (( +. ) (float_of_int (arg188_i)) (1.0e-0)))
    in
    let rec fun202_work arg207_filter arg206_originalOffset arg205_mat arg203_acc arg204_i =
            if ( = ) (arg204_i) (17) then
                arg203_acc
            else
                fun202_work (arg207_filter) (arg206_originalOffset) (arg205_mat) (( +. ) (arg203_acc) (( *. ) (Array.get (arg205_mat) (( + ) (arg206_originalOffset) (arg204_i))) (Array.get (arg207_filter) (arg204_i)))) (( + ) (arg204_i) (1))
    in
    let fun208_convolute17Worker arg190_filter arg191_rows arg192_cols arg193_mat arg194_idx =
        let var195_row  =
            ( / ) (arg194_idx) (arg192_cols)
        in
        let var196_col  =
            ( mod ) (arg194_idx) (arg192_cols)
        in
        let var197_originalRows  =
            arg191_rows
        in
        let var198_originalCols  =
            ( + ) (arg192_cols) (16)
        in
        let var199_originalRow  =
            var195_row
        in
        let var200_originalCol  =
            ( + ) (var196_col) (8)
        in
        let var201_originalOffset  =
            ( - ) (( + ) (( * ) (var199_originalRow) (var198_originalCols)) (var200_originalCol)) (8)
        in
        fun202_work (arg190_filter) (var201_originalOffset) (arg193_mat) (0.0) (0)
    in
    let fun223_bm_runonce arg220_matA arg219_resCols arg218_resRows arg217_filter17 arg216_resCols arg215_resRows arg213__ =
        let var214_bm_t_start  =
            Unix.gettimeofday (())
        in
        let var221_matRes  =
            gpuhost_fun208_convolute17Worker [|1; arg218_resRows; arg219_resCols; ( * ) (arg215_resRows) (arg216_resCols)|] [||] (arg217_filter17) (arg220_matA)
        in
        let var222_bm_t_end  =
            Unix.gettimeofday (())
        in
        ( -. ) (var222_bm_t_end) (var214_bm_t_start)
    in
    let rec fun225_bm_iter arg235_resRows arg234_resCols arg233_filter17 arg232_resRows arg231_resCols arg230_matA arg228_n arg226_i arg227_acc =
            if ( >= ) (arg226_i) (arg228_n) then
                arg227_acc
            else
                let var229__  =
                    ()
                in
                let var236_res  =
                    fun223_bm_runonce (arg230_matA) (arg231_resCols) (arg232_resRows) (arg233_filter17) (arg234_resCols) (arg235_resRows) (())
                in
                let var237_newacc  =
                    Array.append (arg227_acc) ([|var236_res|])
                in
                fun225_bm_iter (arg235_resRows) (arg234_resCols) (arg233_filter17) (arg232_resRows) (arg231_resCols) (arg230_matA) (arg228_n) (( + ) (arg226_i) (1)) (var237_newacc)
    in
    let fun244_bm_runmultiple arg243_matA arg242_resCols arg241_resRows arg240_filter17 arg239_resCols arg238_resRows arg224_n =
        fun225_bm_iter (arg238_resRows) (arg239_resCols) (arg240_filter17) (arg241_resRows) (arg242_resCols) (arg243_matA) (arg224_n) (0) ([||])
    in
    let rec fun247_quicksort_rec arg249_pivot arg250_lt_pivot arg251_geq_pivot arg252_remaining =
            if ( = ) (Array.length (arg252_remaining)) (0) then
                let var253_seq_lt  =
                    fun248_quicksort (arg250_lt_pivot)
                in
                let var254_seq_pivot  =
                    [|arg249_pivot|]
                in
                let var255_seq_geq  =
                    fun248_quicksort (arg251_geq_pivot)
                in
                Array.append (Array.append (var253_seq_lt) (var254_seq_pivot)) (var255_seq_geq)
            else
                let var256_e  =
                    fun1_head (arg252_remaining)
                in
                let var257_t  =
                    fun3_tail (arg252_remaining)
                in
                if ( < ) (var256_e) (arg249_pivot) then
                    fun247_quicksort_rec (arg249_pivot) ((fun x xs -> Array.append [|x|] xs) (var256_e) (arg250_lt_pivot)) (arg251_geq_pivot) (var257_t)
                else
                    fun247_quicksort_rec (arg249_pivot) (arg250_lt_pivot) ((fun x xs -> Array.append [|x|] xs) (var256_e) (arg251_geq_pivot)) (var257_t)
        and fun248_quicksort arg258_arr =
            if ( <= ) (Array.length (arg258_arr)) (1) then
                arg258_arr
            else
                fun247_quicksort_rec (fun1_head (arg258_arr)) ([||]) ([||]) (fun3_tail (arg258_arr))
    in
    let fun259_bm_sort arg245_arr =
        let var246_n  =
            Array.length (arg245_arr)
        in
        fun248_quicksort (arg245_arr)
    in
    let fun263_bm_median arg260_arr =
        let var261_n  =
            Array.length (arg260_arr)
        in
        let var262_sorted  =
            fun259_bm_sort (arg260_arr)
        in
        if ( = ) (( mod ) (var261_n) (2)) (0) then
            ( /. ) (( +. ) (Array.get (arg260_arr) (( - ) (( / ) (var261_n) (2)) (1))) (Array.get (arg260_arr) (( / ) (var261_n) (2)))) (2.0e+0)
        else
            Array.get (arg260_arr) (( / ) (var261_n) (2))
    in
    let rec fun266_work arg270_arr arg269_n arg267_i arg268_acc =
            if ( = ) (arg267_i) (arg269_n) then
                arg268_acc
            else
                fun266_work (arg270_arr) (arg269_n) (( + ) (arg267_i) (1)) (( +. ) (arg268_acc) (Array.get (arg270_arr) (arg267_i)))
    in
    let fun271_bm_sum arg264_arr =
        let var265_n  =
            Array.length (arg264_arr)
        in
        fun266_work (arg264_arr) (var265_n) (0) (0.0)
    in
    let rec fun274_work arg278_arr arg277_n arg275_i arg276_acc =
            if ( = ) (arg275_i) (arg277_n) then
                arg276_acc
            else
                let var279_e  =
                    Array.get (arg278_arr) (arg275_i)
                in
                fun274_work (arg278_arr) (arg277_n) (( + ) (arg275_i) (1)) (if ( > ) (var279_e) (arg276_acc) then
                    var279_e
                else
                    arg276_acc)
    in
    let fun280_bm_max arg272_arr =
        let var273_n  =
            Array.length (arg272_arr)
        in
        fun274_work (arg272_arr) (var273_n) (1) (Array.get (arg272_arr) (0))
    in
    let rec fun283_work arg287_arr arg286_n arg284_i arg285_acc =
            if ( = ) (arg284_i) (arg286_n) then
                arg285_acc
            else
                let var288_e  =
                    Array.get (arg287_arr) (arg284_i)
                in
                fun283_work (arg287_arr) (arg286_n) (( + ) (arg284_i) (1)) (if ( < ) (var288_e) (arg285_acc) then
                    var288_e
                else
                    arg285_acc)
    in
    let fun289_bm_min arg281_arr =
        let var282_n  =
            Array.length (arg281_arr)
        in
        fun283_work (arg281_arr) (var282_n) (1) (Array.get (arg281_arr) (0))
    in
    let fun292_bm_dist arg290_a arg291_b =
        if ( > ) (arg290_a) (arg291_b) then
            ( -. ) (arg290_a) (arg291_b)
        else
            ( -. ) (arg291_b) (arg290_a)
    in
    let var183_matA_rows  =
        4096
    in
    let var184_matA_cols  =
        4096
    in
    let var209_matA  =
        fun96_matrixInitf (var183_matA_rows) (var184_matA_cols) (fun187_matAinitfun_v3)
    in
    let var210_filter17  =
        fun14_seqInit (17) (fun189_filter17initfun)
    in
    let var211_resRows  =
        var183_matA_rows
    in
    let var212_resCols  =
        ( - ) (var184_matA_cols) (16)
    in
    let var293__  =
        ()
    in
    let var294_bmres_warmup  =
        fun244_bm_runmultiple (var209_matA) (var212_resCols) (var211_resRows) (var210_filter17) (var212_resCols) (var211_resRows) (4)
    in
    let var295__  =
        ()
    in
    let var296_bmres_iters  =
        fun244_bm_runmultiple (var209_matA) (var212_resCols) (var211_resRows) (var210_filter17) (var212_resCols) (var211_resRows) (15)
    in
    let var359__  =
        let var297_median  =
            fun263_bm_median (var296_bmres_iters)
        in
        let var298_sum  =
            fun271_bm_sum (var296_bmres_iters)
        in
        let var299_avg  =
            ( /. ) (var298_sum) (1.50e+1)
        in
        let var300_max  =
            fun280_bm_max (var296_bmres_iters)
        in
        let var301_min  =
            fun289_bm_min (var296_bmres_iters)
        in
        let var302_variance  =
            fun280_bm_max ([|fun292_bm_dist (var299_avg) (var300_max); fun292_bm_dist (var299_avg) (var301_min)|])
        in
        let var303_median  =
            ( *. ) (var297_median) (1.0e+3)
        in
        let var304_sum  =
            ( *. ) (var298_sum) (1.0e+3)
        in
        let var305_avg  =
            ( *. ) (var299_avg) (1.0e+3)
        in
        let var306_max  =
            ( *. ) (var300_max) (1.0e+3)
        in
        let var307_min  =
            ( *. ) (var301_min) (1.0e+3)
        in
        let var308_variance  =
            ( *. ) (var302_variance) (1.0e+3)
        in
        let var309__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var310__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var311__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'1'; '5'|])
        in
        let var312__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var313__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var314__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var303_median))
        in
        let var315__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var316__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var317__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var306_max))
        in
        let var318__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var319__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var320__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var307_min))
        in
        let var321__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var322__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var323__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var305_avg))
        in
        let var324__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var325__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var326__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var308_variance))
        in
        let var327__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var328_median  =
            fun263_bm_median (var294_bmres_warmup)
        in
        let var329_sum  =
            fun271_bm_sum (var294_bmres_warmup)
        in
        let var330_avg  =
            ( /. ) (var329_sum) (4.0e+0)
        in
        let var331_max  =
            fun280_bm_max (var294_bmres_warmup)
        in
        let var332_min  =
            fun289_bm_min (var294_bmres_warmup)
        in
        let var333_variance  =
            fun280_bm_max ([|fun292_bm_dist (var330_avg) (var331_max); fun292_bm_dist (var330_avg) (var332_min)|])
        in
        let var334_median  =
            ( *. ) (var328_median) (1.0e+3)
        in
        let var335_sum  =
            ( *. ) (var329_sum) (1.0e+3)
        in
        let var336_avg  =
            ( *. ) (var330_avg) (1.0e+3)
        in
        let var337_max  =
            ( *. ) (var331_max) (1.0e+3)
        in
        let var338_min  =
            ( *. ) (var332_min) (1.0e+3)
        in
        let var339_variance  =
            ( *. ) (var333_variance) (1.0e+3)
        in
        let var340__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'; '\n'; '['; 'w'; 'a'; 'r'; 'm'; 'u'; 'p'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var341__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var342__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'4'|])
        in
        let var343__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var344__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var345__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var334_median))
        in
        let var346__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var347__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var348__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var337_max))
        in
        let var349__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var350__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var351__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var338_min))
        in
        let var352__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var353__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var354__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var336_avg))
        in
        let var355__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var356__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var357__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var339_variance))
        in
        let var358__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        ()
    in
    ()