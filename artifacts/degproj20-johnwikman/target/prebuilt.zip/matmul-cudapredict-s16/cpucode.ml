open Printf

external gpuhost_fun141_matrixMulfWorker: int array -> float array -> float array -> float array -> float array = "gpuhost_fun141_matrixMulfWorker"

let main =
    let fun1_head arg0_s =
        Array.get (arg0_s) (0)
    in
    let fun3_tail arg2_s =
        (fun xs start len -> Array.sub xs (min ((Array.length xs) - 1) start) (min ((Array.length xs) - start) len)) (arg2_s) (1) (Array.length (arg2_s))
    in
    let fun5_null arg4_l =
        ( = ) (Array.length (arg4_l)) (0)
    in
    let fun8_map arg6_f arg7_seq =
        Array.map (arg6_f) (arg7_seq)
    in
    let fun11_mapi arg9_f arg10_seq =
        Array.mapi (arg9_f) (arg10_seq)
    in
    let fun14_seqInit arg12_size arg13_f =
        Array.init (arg12_size) (arg13_f)
    in
    let rec fun16_int2string_rechelper arg17_n =
            if ( < ) (arg17_n) (10) then
                [|char_of_int (( + ) (arg17_n) (int_of_char ('0')))|]
            else
                let var18_d  =
                    [|char_of_int (( + ) (( mod ) (arg17_n) (10)) (int_of_char ('0')))|]
                in
                Array.append (fun16_int2string_rechelper (( / ) (arg17_n) (10))) (var18_d)
    in
    let fun19_int2string arg15_n =
        if ( < ) (arg15_n) (0) then
            (fun x xs -> Array.append [|x|] xs) ('-') (fun16_int2string_rechelper (( ~- ) (arg15_n)))
        else
            fun16_int2string_rechelper (arg15_n)
    in
    let fun21_float2string arg20_f =
        Array.of_seq (String.to_seq (string_of_float (arg20_f)))
    in
    let rec fun22_strJoin arg23_delim arg24_strs =
            if ( = ) (Array.length (arg24_strs)) (0) then
                [||]
            else
                if ( = ) (Array.length (arg24_strs)) (1) then
                    fun1_head (arg24_strs)
                else
                    Array.append (Array.append (fun1_head (arg24_strs)) (arg23_delim)) (fun22_strJoin (arg23_delim) (fun3_tail (arg24_strs)))
    in
    let fun26_printint arg25_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg25_i))
    in
    let fun28_printintln arg27_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (Array.append (fun19_int2string (arg27_i)) ([|'\n'|]))
    in
    let rec fun31_printloop arg33_arr arg32_i =
            if ( = ) (arg32_i) (Array.length (arg33_arr)) then
                ()
            else
                let var34__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var35__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg32_i))
                in
                let var36__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var37__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg33_arr) (arg32_i)))
                in
                let var38__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun31_printloop (arg33_arr) (( + ) (arg32_i) (1))
    in
    let fun42_printintarr arg29_name arg30_arr =
        let var39__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var40__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg29_name)
        in
        let var41__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun31_printloop (arg30_arr) (0)
    in
    let rec fun45_printloop arg47_arr arg46_i =
            if ( = ) (arg46_i) (Array.length (arg47_arr)) then
                ()
            else
                let var48__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var49__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg46_i))
                in
                let var50__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var51__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg47_arr) (arg46_i)))
                in
                let var52__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun45_printloop (arg47_arr) (( + ) (arg46_i) (1))
    in
    let fun56_printfloatarr arg43_name arg44_arr =
        let var53__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var54__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg43_name)
        in
        let var55__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun45_printloop (arg44_arr) (0)
    in
    let rec fun59_printloop arg62_vec arg61_size arg60_i =
            if ( = ) (arg60_i) (arg61_size) then
                ()
            else
                let var63__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg62_vec) (arg60_i)))
                in
                let var64__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun59_printloop (arg62_vec) (arg61_size) (( + ) (arg60_i) (1))
    in
    let fun66_printSeqi arg57_size arg58_vec =
        let var65__  =
            fun59_printloop (arg58_vec) (arg57_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let rec fun69_printloop arg72_vec arg71_size arg70_i =
            if ( = ) (arg70_i) (arg71_size) then
                ()
            else
                let var73__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg72_vec) (arg70_i)))
                in
                let var74__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun69_printloop (arg72_vec) (arg71_size) (( + ) (arg70_i) (1))
    in
    let fun76_printSeqf arg67_size arg68_vec =
        let var75__  =
            fun69_printloop (arg68_vec) (arg67_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let fun80_matrixMkf arg77_rows arg78_cols arg79_v =
        Array.make (( * ) (arg77_rows) (arg78_cols)) (arg79_v)
    in
    let fun86_matrixGetf arg81_row arg82_col arg83_m_rows arg84_m_cols arg85_m =
        Array.get (arg85_m) (( + ) (( * ) (arg84_m_cols) (arg81_row)) (arg82_col))
    in
    let fun95_seqInitFun arg94_f arg91_cols arg90_i =
        let var92_row  =
            ( / ) (arg90_i) (arg91_cols)
        in
        let var93_col  =
            ( mod ) (arg90_i) (arg91_cols)
        in
        arg94_f (var92_row) (var93_col)
    in
    let fun96_matrixInitf arg87_rows arg88_cols arg89_f =
        fun14_seqInit (( * ) (arg87_rows) (arg88_cols)) (fun95_seqInitFun (arg89_f) (arg88_cols))
    in
    let rec fun100_printrc arg107_m arg104_m_cols arg103_m_rows arg101_row arg102_col =
            if ( = ) (arg101_row) (arg103_m_rows) then
                [||]
            else
                let var105_next_col  =
                    ( mod ) (( + ) (arg102_col) (1)) (arg104_m_cols)
                in
                let var106_next_row  =
                    if ( = ) (var105_next_col) (0) then
                        ( + ) (arg101_row) (1)
                    else
                        arg101_row
                in
                fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg101_row) (arg102_col) (arg103_m_rows) (arg104_m_cols) (arg107_m)); if ( = ) (var105_next_col) (0) then
                    [|'\n'|]
                else
                    [|' '|]; fun100_printrc (arg107_m) (arg104_m_cols) (arg103_m_rows) (var106_next_row) (var105_next_col)|])
    in
    let fun108_matrix2strf arg97_m_rows arg98_m_cols arg99_m =
        fun100_printrc (arg99_m) (arg98_m_cols) (arg97_m_rows) (0) (0)
    in
    let rec fun112_printrc arg119_m arg116_m_cols arg115_m_rows arg113_row arg114_col =
            if ( = ) (arg113_row) (arg115_m_rows) then
                [||]
            else
                let var117_next_col  =
                    ( mod ) (( + ) (arg114_col) (1)) (arg116_m_cols)
                in
                let var118_next_row  =
                    if ( = ) (var117_next_col) (0) then
                        ( + ) (arg113_row) (1)
                    else
                        arg113_row
                in
                let var120__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg113_row) (arg114_col) (arg115_m_rows) (arg116_m_cols) (arg119_m)); if ( = ) (var117_next_col) (0) then
                        [|'\n'|]
                    else
                        [|' '|]|]))
                in
                fun112_printrc (arg119_m) (arg116_m_cols) (arg115_m_rows) (var118_next_row) (var117_next_col)
    in
    let fun121_printMatrixf arg109_m_rows arg110_m_cols arg111_m =
        fun112_printrc (arg111_m) (arg110_m_cols) (arg109_m_rows) (0) (0)
    in
    let rec fun132_dotprod arg140_b_cols arg139_b arg138_a arg137_innerDim arg133_acc arg134_p arg135_a_offset arg136_b_offset =
            if ( = ) (arg134_p) (arg137_innerDim) then
                arg133_acc
            else
                fun132_dotprod (arg140_b_cols) (arg139_b) (arg138_a) (arg137_innerDim) (( +. ) (arg133_acc) (( *. ) (Array.get (arg138_a) (arg135_a_offset)) (Array.get (arg139_b) (arg136_b_offset)))) (( + ) (arg134_p) (1)) (( + ) (arg135_a_offset) (1)) (( + ) (arg136_b_offset) (arg140_b_cols))
    in
    let fun141_matrixMulfWorker arg122_innerDim arg123_a_rows arg124_b_cols arg125_a arg126_b arg127_idx =
        let var128_row  =
            ( / ) (arg127_idx) (arg124_b_cols)
        in
        let var129_col  =
            ( mod ) (arg127_idx) (arg124_b_cols)
        in
        let var130_a_start_offset  =
            ( * ) (arg122_innerDim) (var128_row)
        in
        let var131_b_start_offset  =
            var129_col
        in
        fun132_dotprod (arg124_b_cols) (arg126_b) (arg125_a) (arg122_innerDim) (0.0) (0) (var130_a_start_offset) (var131_b_start_offset)
    in
    let rec fun152_dotprod arg159_outerDim arg158_a arg157_innerDim arg153_acc arg154_p arg155_aT_offset arg156_a_offset =
            if ( = ) (arg154_p) (arg157_innerDim) then
                arg153_acc
            else
                fun152_dotprod (arg159_outerDim) (arg158_a) (arg157_innerDim) (( +. ) (arg153_acc) (( *. ) (Array.get (arg158_a) (arg155_aT_offset)) (Array.get (arg158_a) (arg156_a_offset)))) (( + ) (arg154_p) (1)) (( + ) (arg155_aT_offset) (arg159_outerDim)) (( + ) (arg156_a_offset) (arg159_outerDim))
    in
    let fun160_matrixATAfWorker arg142_rows arg143_cols arg144_a arg145_idx =
        let var146_innerDim  =
            arg142_rows
        in
        let var147_outerDim  =
            arg143_cols
        in
        let var148_row  =
            ( / ) (arg145_idx) (arg143_cols)
        in
        let var149_col  =
            ( mod ) (arg145_idx) (arg143_cols)
        in
        let var150_aT_start_offset  =
            var148_row
        in
        let var151_a_start_offset  =
            var149_col
        in
        fun152_dotprod (var147_outerDim) (arg144_a) (var146_innerDim) (0.0) (0) (var150_aT_start_offset) (var151_a_start_offset)
    in
    let rec fun172_dotprodTransposeLhs arg181_b_cols arg180_a_cols arg179_b arg178_a arg177_b_rows arg173_acc arg174_p arg175_aT_offset arg176_b_offset =
            if ( = ) (arg174_p) (arg177_b_rows) then
                arg173_acc
            else
                fun172_dotprodTransposeLhs (arg181_b_cols) (arg180_a_cols) (arg179_b) (arg178_a) (arg177_b_rows) (( +. ) (arg173_acc) (( *. ) (Array.get (arg178_a) (arg175_aT_offset)) (Array.get (arg179_b) (arg176_b_offset)))) (( + ) (arg174_p) (1)) (( + ) (arg175_aT_offset) (arg180_a_cols)) (( + ) (arg176_b_offset) (arg181_b_cols))
    in
    let fun182_matrixMulTransposeLhsfWorker arg161_a_rows arg162_a_cols arg163_b_rows arg164_b_cols arg165_a arg166_b arg167_idx =
        let var168_row  =
            ( / ) (arg167_idx) (arg164_b_cols)
        in
        let var169_col  =
            ( mod ) (arg167_idx) (arg164_b_cols)
        in
        let var170_aT_start_offset  =
            var168_row
        in
        let var171_b_start_offset  =
            var169_col
        in
        fun172_dotprodTransposeLhs (arg164_b_cols) (arg162_a_cols) (arg166_b) (arg165_a) (arg163_b_rows) (0.0) (0) (var170_aT_start_offset) (var171_b_start_offset)
    in
    let fun189_matAinitfun arg187_row arg188_col =
        float_of_int (( + ) (( * ) (arg187_row) (arg187_row)) (arg188_col))
    in
    let fun192_matBinitfun arg190_row arg191_col =
        ( /. ) (float_of_int (( / ) (( * ) (( + ) (arg190_row) (19)) (17)) (( + ) (arg191_col) (13)))) (float_of_int (( + ) (arg190_row) (11)))
    in
    let fun195_matAinitfun_v2 arg193_row arg194_col =
        ( -. ) (( /. ) (float_of_int (( + ) (( * ) (arg193_row) (arg193_row)) (arg194_col))) (3.0e+0)) (1.400000e-2)
    in
    let fun198_matBinitfun_v2 arg196_row arg197_col =
        float_of_int (( mod ) (( / ) (( * ) (( + ) (arg196_row) (19)) (17)) (( + ) (arg197_col) (13))) (2))
    in
    let fun213_bm_runonce arg210_matB arg209_matA arg208_matB_cols arg207_matA_rows arg206_innerDim arg205_matB_cols arg204_matA_rows arg202__ =
        let var203_bm_t_start  =
            Unix.gettimeofday (())
        in
        let var211_matAxB  =
            if (( < ) (( * ) (( * ) (arg204_matA_rows) (arg205_matB_cols)) (( + ) (50) (( + ) (12) (( + ) (0) (( + ) (7) (( + ) (7) (( + ) (5) (( + ) (1) (( + ) (16) (( + ) (0) (( * ) (94) (if ( < ) (1) (arg206_innerDim) then
                arg206_innerDim
            else
                1)))))))))))) (( + ) (( + ) (( * ) (( + ) (( + ) (( * ) (arg204_matA_rows) (arg205_matB_cols)) (Array.length (arg209_matA))) (Array.length (arg210_matB))) (10)) (40000000)) (( * ) (( + ) (12) (( + ) (0) (( + ) (64) (( + ) (64) (( + ) (30) (( + ) (1) (( + ) (16) (( + ) (0) (( * ) (995) (if ( < ) (1) (arg206_innerDim) then
                arg206_innerDim
            else
                1)))))))))) (( / ) (( + ) (( * ) (arg204_matA_rows) (arg205_matB_cols)) (( - ) (1536) (1))) (1536))))) then (Array.init (( * ) (arg204_matA_rows) (arg205_matB_cols)) (fun141_matrixMulfWorker (arg206_innerDim) (arg207_matA_rows) (arg208_matB_cols) (arg209_matA) (arg210_matB))) else (gpuhost_fun141_matrixMulfWorker [|1; arg206_innerDim; arg207_matA_rows; arg208_matB_cols; ( * ) (arg204_matA_rows) (arg205_matB_cols)|] [||] (arg209_matA) (arg210_matB))
        in
        let var212_bm_t_end  =
            Unix.gettimeofday (())
        in
        ( -. ) (var212_bm_t_end) (var203_bm_t_start)
    in
    let rec fun215_bm_iter arg226_matA_rows arg225_matB_cols arg224_innerDim arg223_matA_rows arg222_matB_cols arg221_matA arg220_matB arg218_n arg216_i arg217_acc =
            if ( >= ) (arg216_i) (arg218_n) then
                arg217_acc
            else
                let var219__  =
                    ()
                in
                let var227_res  =
                    fun213_bm_runonce (arg220_matB) (arg221_matA) (arg222_matB_cols) (arg223_matA_rows) (arg224_innerDim) (arg225_matB_cols) (arg226_matA_rows) (())
                in
                let var228_newacc  =
                    Array.append (arg217_acc) ([|var227_res|])
                in
                fun215_bm_iter (arg226_matA_rows) (arg225_matB_cols) (arg224_innerDim) (arg223_matA_rows) (arg222_matB_cols) (arg221_matA) (arg220_matB) (arg218_n) (( + ) (arg216_i) (1)) (var228_newacc)
    in
    let fun236_bm_runmultiple arg235_matB arg234_matA arg233_matB_cols arg232_matA_rows arg231_innerDim arg230_matB_cols arg229_matA_rows arg214_n =
        fun215_bm_iter (arg229_matA_rows) (arg230_matB_cols) (arg231_innerDim) (arg232_matA_rows) (arg233_matB_cols) (arg234_matA) (arg235_matB) (arg214_n) (0) ([||])
    in
    let rec fun239_quicksort_rec arg241_pivot arg242_lt_pivot arg243_geq_pivot arg244_remaining =
            if ( = ) (Array.length (arg244_remaining)) (0) then
                let var245_seq_lt  =
                    fun240_quicksort (arg242_lt_pivot)
                in
                let var246_seq_pivot  =
                    [|arg241_pivot|]
                in
                let var247_seq_geq  =
                    fun240_quicksort (arg243_geq_pivot)
                in
                Array.append (Array.append (var245_seq_lt) (var246_seq_pivot)) (var247_seq_geq)
            else
                let var248_e  =
                    fun1_head (arg244_remaining)
                in
                let var249_t  =
                    fun3_tail (arg244_remaining)
                in
                if ( < ) (var248_e) (arg241_pivot) then
                    fun239_quicksort_rec (arg241_pivot) ((fun x xs -> Array.append [|x|] xs) (var248_e) (arg242_lt_pivot)) (arg243_geq_pivot) (var249_t)
                else
                    fun239_quicksort_rec (arg241_pivot) (arg242_lt_pivot) ((fun x xs -> Array.append [|x|] xs) (var248_e) (arg243_geq_pivot)) (var249_t)
        and fun240_quicksort arg250_arr =
            if ( <= ) (Array.length (arg250_arr)) (1) then
                arg250_arr
            else
                fun239_quicksort_rec (fun1_head (arg250_arr)) ([||]) ([||]) (fun3_tail (arg250_arr))
    in
    let fun251_bm_sort arg237_arr =
        let var238_n  =
            Array.length (arg237_arr)
        in
        fun240_quicksort (arg237_arr)
    in
    let fun255_bm_median arg252_arr =
        let var253_n  =
            Array.length (arg252_arr)
        in
        let var254_sorted  =
            fun251_bm_sort (arg252_arr)
        in
        if ( = ) (( mod ) (var253_n) (2)) (0) then
            ( /. ) (( +. ) (Array.get (arg252_arr) (( - ) (( / ) (var253_n) (2)) (1))) (Array.get (arg252_arr) (( / ) (var253_n) (2)))) (2.0e+0)
        else
            Array.get (arg252_arr) (( / ) (var253_n) (2))
    in
    let rec fun258_work arg262_arr arg261_n arg259_i arg260_acc =
            if ( = ) (arg259_i) (arg261_n) then
                arg260_acc
            else
                fun258_work (arg262_arr) (arg261_n) (( + ) (arg259_i) (1)) (( +. ) (arg260_acc) (Array.get (arg262_arr) (arg259_i)))
    in
    let fun263_bm_sum arg256_arr =
        let var257_n  =
            Array.length (arg256_arr)
        in
        fun258_work (arg256_arr) (var257_n) (0) (0.0)
    in
    let rec fun266_work arg270_arr arg269_n arg267_i arg268_acc =
            if ( = ) (arg267_i) (arg269_n) then
                arg268_acc
            else
                let var271_e  =
                    Array.get (arg270_arr) (arg267_i)
                in
                fun266_work (arg270_arr) (arg269_n) (( + ) (arg267_i) (1)) (if ( > ) (var271_e) (arg268_acc) then
                    var271_e
                else
                    arg268_acc)
    in
    let fun272_bm_max arg264_arr =
        let var265_n  =
            Array.length (arg264_arr)
        in
        fun266_work (arg264_arr) (var265_n) (1) (Array.get (arg264_arr) (0))
    in
    let rec fun275_work arg279_arr arg278_n arg276_i arg277_acc =
            if ( = ) (arg276_i) (arg278_n) then
                arg277_acc
            else
                let var280_e  =
                    Array.get (arg279_arr) (arg276_i)
                in
                fun275_work (arg279_arr) (arg278_n) (( + ) (arg276_i) (1)) (if ( < ) (var280_e) (arg277_acc) then
                    var280_e
                else
                    arg277_acc)
    in
    let fun281_bm_min arg273_arr =
        let var274_n  =
            Array.length (arg273_arr)
        in
        fun275_work (arg273_arr) (var274_n) (1) (Array.get (arg273_arr) (0))
    in
    let fun284_bm_dist arg282_a arg283_b =
        if ( > ) (arg282_a) (arg283_b) then
            ( -. ) (arg282_a) (arg283_b)
        else
            ( -. ) (arg283_b) (arg282_a)
    in
    let var183_matA_rows  =
        16
    in
    let var184_matA_cols  =
        16
    in
    let var185_matB_rows  =
        16
    in
    let var186_matB_cols  =
        16
    in
    let var199_matA  =
        fun96_matrixInitf (var183_matA_rows) (var184_matA_cols) (fun195_matAinitfun_v2)
    in
    let var200_matB  =
        fun96_matrixInitf (var185_matB_rows) (var186_matB_cols) (fun198_matBinitfun_v2)
    in
    let var201_innerDim  =
        var184_matA_cols
    in
    let var285__  =
        ()
    in
    let var286_bmres_warmup  =
        fun236_bm_runmultiple (var200_matB) (var199_matA) (var186_matB_cols) (var183_matA_rows) (var201_innerDim) (var186_matB_cols) (var183_matA_rows) (4)
    in
    let var287__  =
        ()
    in
    let var288_bmres_iters  =
        fun236_bm_runmultiple (var200_matB) (var199_matA) (var186_matB_cols) (var183_matA_rows) (var201_innerDim) (var186_matB_cols) (var183_matA_rows) (15)
    in
    let var351__  =
        let var289_median  =
            fun255_bm_median (var288_bmres_iters)
        in
        let var290_sum  =
            fun263_bm_sum (var288_bmres_iters)
        in
        let var291_avg  =
            ( /. ) (var290_sum) (1.50e+1)
        in
        let var292_max  =
            fun272_bm_max (var288_bmres_iters)
        in
        let var293_min  =
            fun281_bm_min (var288_bmres_iters)
        in
        let var294_variance  =
            fun272_bm_max ([|fun284_bm_dist (var291_avg) (var292_max); fun284_bm_dist (var291_avg) (var293_min)|])
        in
        let var295_median  =
            ( *. ) (var289_median) (1.0e+3)
        in
        let var296_sum  =
            ( *. ) (var290_sum) (1.0e+3)
        in
        let var297_avg  =
            ( *. ) (var291_avg) (1.0e+3)
        in
        let var298_max  =
            ( *. ) (var292_max) (1.0e+3)
        in
        let var299_min  =
            ( *. ) (var293_min) (1.0e+3)
        in
        let var300_variance  =
            ( *. ) (var294_variance) (1.0e+3)
        in
        let var301__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var302__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var303__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'1'; '5'|])
        in
        let var304__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var305__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var306__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var295_median))
        in
        let var307__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var308__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var309__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var298_max))
        in
        let var310__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var311__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var312__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var299_min))
        in
        let var313__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var314__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var315__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var297_avg))
        in
        let var316__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var317__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var318__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var300_variance))
        in
        let var319__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var320_median  =
            fun255_bm_median (var286_bmres_warmup)
        in
        let var321_sum  =
            fun263_bm_sum (var286_bmres_warmup)
        in
        let var322_avg  =
            ( /. ) (var321_sum) (4.0e+0)
        in
        let var323_max  =
            fun272_bm_max (var286_bmres_warmup)
        in
        let var324_min  =
            fun281_bm_min (var286_bmres_warmup)
        in
        let var325_variance  =
            fun272_bm_max ([|fun284_bm_dist (var322_avg) (var323_max); fun284_bm_dist (var322_avg) (var324_min)|])
        in
        let var326_median  =
            ( *. ) (var320_median) (1.0e+3)
        in
        let var327_sum  =
            ( *. ) (var321_sum) (1.0e+3)
        in
        let var328_avg  =
            ( *. ) (var322_avg) (1.0e+3)
        in
        let var329_max  =
            ( *. ) (var323_max) (1.0e+3)
        in
        let var330_min  =
            ( *. ) (var324_min) (1.0e+3)
        in
        let var331_variance  =
            ( *. ) (var325_variance) (1.0e+3)
        in
        let var332__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'; '\n'; '['; 'w'; 'a'; 'r'; 'm'; 'u'; 'p'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var333__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var334__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'4'|])
        in
        let var335__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var336__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var337__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var326_median))
        in
        let var338__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var339__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var340__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var329_max))
        in
        let var341__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var342__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var343__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var330_min))
        in
        let var344__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var345__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var346__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var328_avg))
        in
        let var347__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var348__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var349__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var331_variance))
        in
        let var350__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        ()
    in
    ()