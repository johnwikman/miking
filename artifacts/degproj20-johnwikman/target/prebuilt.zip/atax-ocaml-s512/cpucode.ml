open Printf



let main =
    let fun1_head arg0_s =
        Array.get (arg0_s) (0)
    in
    let fun3_tail arg2_s =
        (fun xs start len -> Array.sub xs (min ((Array.length xs) - 1) start) (min ((Array.length xs) - start) len)) (arg2_s) (1) (Array.length (arg2_s))
    in
    let fun5_null arg4_l =
        ( = ) (Array.length (arg4_l)) (0)
    in
    let fun8_map arg6_f arg7_seq =
        Array.map (arg6_f) (arg7_seq)
    in
    let fun11_mapi arg9_f arg10_seq =
        Array.mapi (arg9_f) (arg10_seq)
    in
    let fun14_seqInit arg12_size arg13_f =
        Array.init (arg12_size) (arg13_f)
    in
    let rec fun16_int2string_rechelper arg17_n =
            if ( < ) (arg17_n) (10) then
                [|char_of_int (( + ) (arg17_n) (int_of_char ('0')))|]
            else
                let var18_d  =
                    [|char_of_int (( + ) (( mod ) (arg17_n) (10)) (int_of_char ('0')))|]
                in
                Array.append (fun16_int2string_rechelper (( / ) (arg17_n) (10))) (var18_d)
    in
    let fun19_int2string arg15_n =
        if ( < ) (arg15_n) (0) then
            (fun x xs -> Array.append [|x|] xs) ('-') (fun16_int2string_rechelper (( ~- ) (arg15_n)))
        else
            fun16_int2string_rechelper (arg15_n)
    in
    let fun21_float2string arg20_f =
        Array.of_seq (String.to_seq (string_of_float (arg20_f)))
    in
    let rec fun22_strJoin arg23_delim arg24_strs =
            if ( = ) (Array.length (arg24_strs)) (0) then
                [||]
            else
                if ( = ) (Array.length (arg24_strs)) (1) then
                    fun1_head (arg24_strs)
                else
                    Array.append (Array.append (fun1_head (arg24_strs)) (arg23_delim)) (fun22_strJoin (arg23_delim) (fun3_tail (arg24_strs)))
    in
    let fun26_printint arg25_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg25_i))
    in
    let fun28_printintln arg27_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (Array.append (fun19_int2string (arg27_i)) ([|'\n'|]))
    in
    let rec fun31_printloop arg33_arr arg32_i =
            if ( = ) (arg32_i) (Array.length (arg33_arr)) then
                ()
            else
                let var34__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var35__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg32_i))
                in
                let var36__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var37__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg33_arr) (arg32_i)))
                in
                let var38__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun31_printloop (arg33_arr) (( + ) (arg32_i) (1))
    in
    let fun42_printintarr arg29_name arg30_arr =
        let var39__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var40__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg29_name)
        in
        let var41__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun31_printloop (arg30_arr) (0)
    in
    let rec fun45_printloop arg47_arr arg46_i =
            if ( = ) (arg46_i) (Array.length (arg47_arr)) then
                ()
            else
                let var48__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var49__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg46_i))
                in
                let var50__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var51__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg47_arr) (arg46_i)))
                in
                let var52__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun45_printloop (arg47_arr) (( + ) (arg46_i) (1))
    in
    let fun56_printfloatarr arg43_name arg44_arr =
        let var53__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var54__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg43_name)
        in
        let var55__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun45_printloop (arg44_arr) (0)
    in
    let rec fun59_printloop arg62_vec arg61_size arg60_i =
            if ( = ) (arg60_i) (arg61_size) then
                ()
            else
                let var63__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg62_vec) (arg60_i)))
                in
                let var64__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun59_printloop (arg62_vec) (arg61_size) (( + ) (arg60_i) (1))
    in
    let fun66_printSeqi arg57_size arg58_vec =
        let var65__  =
            fun59_printloop (arg58_vec) (arg57_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let rec fun69_printloop arg72_vec arg71_size arg70_i =
            if ( = ) (arg70_i) (arg71_size) then
                ()
            else
                let var73__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg72_vec) (arg70_i)))
                in
                let var74__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun69_printloop (arg72_vec) (arg71_size) (( + ) (arg70_i) (1))
    in
    let fun76_printSeqf arg67_size arg68_vec =
        let var75__  =
            fun69_printloop (arg68_vec) (arg67_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let fun80_matrixMkf arg77_rows arg78_cols arg79_v =
        Array.make (( * ) (arg77_rows) (arg78_cols)) (arg79_v)
    in
    let fun86_matrixGetf arg81_row arg82_col arg83_m_rows arg84_m_cols arg85_m =
        Array.get (arg85_m) (( + ) (( * ) (arg84_m_cols) (arg81_row)) (arg82_col))
    in
    let fun95_seqInitFun arg94_f arg91_cols arg90_i =
        let var92_row  =
            ( / ) (arg90_i) (arg91_cols)
        in
        let var93_col  =
            ( mod ) (arg90_i) (arg91_cols)
        in
        arg94_f (var92_row) (var93_col)
    in
    let fun96_matrixInitf arg87_rows arg88_cols arg89_f =
        fun14_seqInit (( * ) (arg87_rows) (arg88_cols)) (fun95_seqInitFun (arg89_f) (arg88_cols))
    in
    let rec fun100_printrc arg107_m arg104_m_cols arg103_m_rows arg101_row arg102_col =
            if ( = ) (arg101_row) (arg103_m_rows) then
                [||]
            else
                let var105_next_col  =
                    ( mod ) (( + ) (arg102_col) (1)) (arg104_m_cols)
                in
                let var106_next_row  =
                    if ( = ) (var105_next_col) (0) then
                        ( + ) (arg101_row) (1)
                    else
                        arg101_row
                in
                fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg101_row) (arg102_col) (arg103_m_rows) (arg104_m_cols) (arg107_m)); if ( = ) (var105_next_col) (0) then
                    [|'\n'|]
                else
                    [|' '|]; fun100_printrc (arg107_m) (arg104_m_cols) (arg103_m_rows) (var106_next_row) (var105_next_col)|])
    in
    let fun108_matrix2strf arg97_m_rows arg98_m_cols arg99_m =
        fun100_printrc (arg99_m) (arg98_m_cols) (arg97_m_rows) (0) (0)
    in
    let rec fun112_printrc arg119_m arg116_m_cols arg115_m_rows arg113_row arg114_col =
            if ( = ) (arg113_row) (arg115_m_rows) then
                [||]
            else
                let var117_next_col  =
                    ( mod ) (( + ) (arg114_col) (1)) (arg116_m_cols)
                in
                let var118_next_row  =
                    if ( = ) (var117_next_col) (0) then
                        ( + ) (arg113_row) (1)
                    else
                        arg113_row
                in
                let var120__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg113_row) (arg114_col) (arg115_m_rows) (arg116_m_cols) (arg119_m)); if ( = ) (var117_next_col) (0) then
                        [|'\n'|]
                    else
                        [|' '|]|]))
                in
                fun112_printrc (arg119_m) (arg116_m_cols) (arg115_m_rows) (var118_next_row) (var117_next_col)
    in
    let fun121_printMatrixf arg109_m_rows arg110_m_cols arg111_m =
        fun112_printrc (arg111_m) (arg110_m_cols) (arg109_m_rows) (0) (0)
    in
    let rec fun132_dotprod arg140_b_cols arg139_b arg138_a arg137_innerDim arg133_acc arg134_p arg135_a_offset arg136_b_offset =
            if ( = ) (arg134_p) (arg137_innerDim) then
                arg133_acc
            else
                fun132_dotprod (arg140_b_cols) (arg139_b) (arg138_a) (arg137_innerDim) (( +. ) (arg133_acc) (( *. ) (Array.get (arg138_a) (arg135_a_offset)) (Array.get (arg139_b) (arg136_b_offset)))) (( + ) (arg134_p) (1)) (( + ) (arg135_a_offset) (1)) (( + ) (arg136_b_offset) (arg140_b_cols))
    in
    let fun141_matrixMulfWorker arg122_innerDim arg123_a_rows arg124_b_cols arg125_a arg126_b arg127_idx =
        let var128_row  =
            ( / ) (arg127_idx) (arg124_b_cols)
        in
        let var129_col  =
            ( mod ) (arg127_idx) (arg124_b_cols)
        in
        let var130_a_start_offset  =
            ( * ) (arg122_innerDim) (var128_row)
        in
        let var131_b_start_offset  =
            var129_col
        in
        fun132_dotprod (arg124_b_cols) (arg126_b) (arg125_a) (arg122_innerDim) (0.0) (0) (var130_a_start_offset) (var131_b_start_offset)
    in
    let rec fun152_dotprod arg159_outerDim arg158_a arg157_innerDim arg153_acc arg154_p arg155_aT_offset arg156_a_offset =
            if ( = ) (arg154_p) (arg157_innerDim) then
                arg153_acc
            else
                fun152_dotprod (arg159_outerDim) (arg158_a) (arg157_innerDim) (( +. ) (arg153_acc) (( *. ) (Array.get (arg158_a) (arg155_aT_offset)) (Array.get (arg158_a) (arg156_a_offset)))) (( + ) (arg154_p) (1)) (( + ) (arg155_aT_offset) (arg159_outerDim)) (( + ) (arg156_a_offset) (arg159_outerDim))
    in
    let fun160_matrixATAfWorker arg142_rows arg143_cols arg144_a arg145_idx =
        let var146_innerDim  =
            arg142_rows
        in
        let var147_outerDim  =
            arg143_cols
        in
        let var148_row  =
            ( / ) (arg145_idx) (arg143_cols)
        in
        let var149_col  =
            ( mod ) (arg145_idx) (arg143_cols)
        in
        let var150_aT_start_offset  =
            var148_row
        in
        let var151_a_start_offset  =
            var149_col
        in
        fun152_dotprod (var147_outerDim) (arg144_a) (var146_innerDim) (0.0) (0) (var150_aT_start_offset) (var151_a_start_offset)
    in
    let rec fun172_dotprodTransposeLhs arg181_b_cols arg180_a_cols arg179_b arg178_a arg177_b_rows arg173_acc arg174_p arg175_aT_offset arg176_b_offset =
            if ( = ) (arg174_p) (arg177_b_rows) then
                arg173_acc
            else
                fun172_dotprodTransposeLhs (arg181_b_cols) (arg180_a_cols) (arg179_b) (arg178_a) (arg177_b_rows) (( +. ) (arg173_acc) (( *. ) (Array.get (arg178_a) (arg175_aT_offset)) (Array.get (arg179_b) (arg176_b_offset)))) (( + ) (arg174_p) (1)) (( + ) (arg175_aT_offset) (arg180_a_cols)) (( + ) (arg176_b_offset) (arg181_b_cols))
    in
    let fun182_matrixMulTransposeLhsfWorker arg161_a_rows arg162_a_cols arg163_b_rows arg164_b_cols arg165_a arg166_b arg167_idx =
        let var168_row  =
            ( / ) (arg167_idx) (arg164_b_cols)
        in
        let var169_col  =
            ( mod ) (arg167_idx) (arg164_b_cols)
        in
        let var170_aT_start_offset  =
            var168_row
        in
        let var171_b_start_offset  =
            var169_col
        in
        fun172_dotprodTransposeLhs (arg164_b_cols) (arg162_a_cols) (arg166_b) (arg165_a) (arg163_b_rows) (0.0) (0) (var170_aT_start_offset) (var171_b_start_offset)
    in
    let fun189_matAinitfun_v2 arg187_row arg188_col =
        ( -. ) (( /. ) (float_of_int (( + ) (( * ) (arg187_row) (arg187_row)) (arg188_col))) (3.0e+0)) (1.400000e-2)
    in
    let fun192_vecXinitfun arg190_row arg191_col =
        float_of_int (( mod ) (( * ) (arg190_row) (10657)) (41081))
    in
    let fun209_bm_runonce arg203_vecX arg202_matA arg201_matA_cols arg200_vecX_cols arg199_matA_rows arg197__ =
        let var198_bm_t_start  =
            Unix.gettimeofday (())
        in
        let var204_vecAx  =
            fun14_seqInit (( * ) (arg199_matA_rows) (arg200_vecX_cols)) (fun141_matrixMulfWorker (arg201_matA_cols) (arg199_matA_rows) (arg200_vecX_cols) (arg202_matA) (arg203_vecX))
        in
        let var205_vecAx_rows  =
            arg199_matA_rows
        in
        let var206_vecAx_cols  =
            arg200_vecX_cols
        in
        let var207_vecATAx  =
            fun14_seqInit (( * ) (arg201_matA_cols) (var206_vecAx_cols)) (fun182_matrixMulTransposeLhsfWorker (arg199_matA_rows) (arg201_matA_cols) (var205_vecAx_rows) (var206_vecAx_cols) (arg202_matA) (var204_vecAx))
        in
        let var208_bm_t_end  =
            Unix.gettimeofday (())
        in
        ( -. ) (var208_bm_t_end) (var198_bm_t_start)
    in
    let rec fun211_bm_iter arg220_matA_rows arg219_vecX_cols arg218_matA_cols arg217_matA arg216_vecX arg214_n arg212_i arg213_acc =
            if ( >= ) (arg212_i) (arg214_n) then
                arg213_acc
            else
                let var215__  =
                    ()
                in
                let var221_res  =
                    fun209_bm_runonce (arg216_vecX) (arg217_matA) (arg218_matA_cols) (arg219_vecX_cols) (arg220_matA_rows) (())
                in
                let var222_newacc  =
                    Array.append (arg213_acc) ([|var221_res|])
                in
                fun211_bm_iter (arg220_matA_rows) (arg219_vecX_cols) (arg218_matA_cols) (arg217_matA) (arg216_vecX) (arg214_n) (( + ) (arg212_i) (1)) (var222_newacc)
    in
    let fun228_bm_runmultiple arg227_vecX arg226_matA arg225_matA_cols arg224_vecX_cols arg223_matA_rows arg210_n =
        fun211_bm_iter (arg223_matA_rows) (arg224_vecX_cols) (arg225_matA_cols) (arg226_matA) (arg227_vecX) (arg210_n) (0) ([||])
    in
    let rec fun231_quicksort_rec arg233_pivot arg234_lt_pivot arg235_geq_pivot arg236_remaining =
            if ( = ) (Array.length (arg236_remaining)) (0) then
                let var237_seq_lt  =
                    fun232_quicksort (arg234_lt_pivot)
                in
                let var238_seq_pivot  =
                    [|arg233_pivot|]
                in
                let var239_seq_geq  =
                    fun232_quicksort (arg235_geq_pivot)
                in
                Array.append (Array.append (var237_seq_lt) (var238_seq_pivot)) (var239_seq_geq)
            else
                let var240_e  =
                    fun1_head (arg236_remaining)
                in
                let var241_t  =
                    fun3_tail (arg236_remaining)
                in
                if ( < ) (var240_e) (arg233_pivot) then
                    fun231_quicksort_rec (arg233_pivot) ((fun x xs -> Array.append [|x|] xs) (var240_e) (arg234_lt_pivot)) (arg235_geq_pivot) (var241_t)
                else
                    fun231_quicksort_rec (arg233_pivot) (arg234_lt_pivot) ((fun x xs -> Array.append [|x|] xs) (var240_e) (arg235_geq_pivot)) (var241_t)
        and fun232_quicksort arg242_arr =
            if ( <= ) (Array.length (arg242_arr)) (1) then
                arg242_arr
            else
                fun231_quicksort_rec (fun1_head (arg242_arr)) ([||]) ([||]) (fun3_tail (arg242_arr))
    in
    let fun243_bm_sort arg229_arr =
        let var230_n  =
            Array.length (arg229_arr)
        in
        fun232_quicksort (arg229_arr)
    in
    let fun247_bm_median arg244_arr =
        let var245_n  =
            Array.length (arg244_arr)
        in
        let var246_sorted  =
            fun243_bm_sort (arg244_arr)
        in
        if ( = ) (( mod ) (var245_n) (2)) (0) then
            ( /. ) (( +. ) (Array.get (arg244_arr) (( - ) (( / ) (var245_n) (2)) (1))) (Array.get (arg244_arr) (( / ) (var245_n) (2)))) (2.0e+0)
        else
            Array.get (arg244_arr) (( / ) (var245_n) (2))
    in
    let rec fun250_work arg254_arr arg253_n arg251_i arg252_acc =
            if ( = ) (arg251_i) (arg253_n) then
                arg252_acc
            else
                fun250_work (arg254_arr) (arg253_n) (( + ) (arg251_i) (1)) (( +. ) (arg252_acc) (Array.get (arg254_arr) (arg251_i)))
    in
    let fun255_bm_sum arg248_arr =
        let var249_n  =
            Array.length (arg248_arr)
        in
        fun250_work (arg248_arr) (var249_n) (0) (0.0)
    in
    let rec fun258_work arg262_arr arg261_n arg259_i arg260_acc =
            if ( = ) (arg259_i) (arg261_n) then
                arg260_acc
            else
                let var263_e  =
                    Array.get (arg262_arr) (arg259_i)
                in
                fun258_work (arg262_arr) (arg261_n) (( + ) (arg259_i) (1)) (if ( > ) (var263_e) (arg260_acc) then
                    var263_e
                else
                    arg260_acc)
    in
    let fun264_bm_max arg256_arr =
        let var257_n  =
            Array.length (arg256_arr)
        in
        fun258_work (arg256_arr) (var257_n) (1) (Array.get (arg256_arr) (0))
    in
    let rec fun267_work arg271_arr arg270_n arg268_i arg269_acc =
            if ( = ) (arg268_i) (arg270_n) then
                arg269_acc
            else
                let var272_e  =
                    Array.get (arg271_arr) (arg268_i)
                in
                fun267_work (arg271_arr) (arg270_n) (( + ) (arg268_i) (1)) (if ( < ) (var272_e) (arg269_acc) then
                    var272_e
                else
                    arg269_acc)
    in
    let fun273_bm_min arg265_arr =
        let var266_n  =
            Array.length (arg265_arr)
        in
        fun267_work (arg265_arr) (var266_n) (1) (Array.get (arg265_arr) (0))
    in
    let rec fun278_work arg284_avg_co arg282_arr arg281_n arg279_i arg280_acc =
            if ( = ) (arg279_i) (arg281_n) then
                arg280_acc
            else
                let var283_elem  =
                    ( *. ) (Array.get (arg282_arr) (arg279_i)) (1.0e+3)
                in
                let var285_subres  =
                    ( -. ) (arg284_avg_co) (var283_elem)
                in
                fun278_work (arg284_avg_co) (arg282_arr) (arg281_n) (( + ) (arg279_i) (1)) (( +. ) (arg280_acc) (( *. ) (var285_subres) (var285_subres)))
    in
    let fun289_bm_variance arg274_avg arg275_arr =
        let var276_n  =
            Array.length (arg275_arr)
        in
        let var277_avg_co  =
            ( *. ) (arg274_avg) (1.0e+3)
        in
        let var286_elem  =
            ( *. ) (Array.get (arg275_arr) (0)) (1.0e+3)
        in
        let var287_subres  =
            ( -. ) (var277_avg_co) (var286_elem)
        in
        let var288_res  =
            fun278_work (var277_avg_co) (arg275_arr) (var276_n) (1) (( *. ) (var287_subres) (var287_subres))
        in
        ( /. ) (var288_res) (float_of_int (( - ) (var276_n) (1)))
    in
    let rec fun292_work arg296_arr arg294_n arg293_i =
            if ( = ) (arg293_i) (arg294_n) then
                ()
            else
                let var295__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|','; ' '|])
                in
                let var297__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg296_arr) (arg293_i)) (1.0e+3)))
                in
                fun292_work (arg296_arr) (arg294_n) (( + ) (arg293_i) (1))
    in
    let fun301_bm_printarr arg290_arr =
        let var291_n  =
            Array.length (arg290_arr)
        in
        let var298__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['|])
        in
        let var299__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg290_arr) (0)) (1.0e+3)))
        in
        let var300__  =
            fun292_work (arg290_arr) (var291_n) (1)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|']'|])
    in
    let fun304_bm_dist arg302_a arg303_b =
        if ( > ) (arg302_a) (arg303_b) then
            ( -. ) (arg302_a) (arg303_b)
        else
            ( -. ) (arg303_b) (arg302_a)
    in
    let var183_matA_rows  =
        512
    in
    let var184_matA_cols  =
        512
    in
    let var185_matB_rows  =
        512
    in
    let var186_matB_cols  =
        512
    in
    let var193_matA  =
        fun96_matrixInitf (var183_matA_rows) (var184_matA_cols) (fun189_matAinitfun_v2)
    in
    let var194_vecX_rows  =
        var184_matA_cols
    in
    let var195_vecX_cols  =
        1
    in
    let var196_vecX  =
        fun96_matrixInitf (var194_vecX_rows) (var195_vecX_cols) (fun192_vecXinitfun)
    in
    let var305__  =
        ()
    in
    let var306_bmres_warmup  =
        fun228_bm_runmultiple (var196_vecX) (var193_matA) (var184_matA_cols) (var195_vecX_cols) (var183_matA_rows) (4)
    in
    let var307__  =
        ()
    in
    let var308_bmres_iters  =
        fun228_bm_runmultiple (var196_vecX) (var193_matA) (var184_matA_cols) (var195_vecX_cols) (var183_matA_rows) (15)
    in
    let var375__  =
        let var309_median  =
            fun247_bm_median (var308_bmres_iters)
        in
        let var310_sum  =
            fun255_bm_sum (var308_bmres_iters)
        in
        let var311_avg  =
            ( /. ) (var310_sum) (1.50e+1)
        in
        let var312_max  =
            fun264_bm_max (var308_bmres_iters)
        in
        let var313_min  =
            fun273_bm_min (var308_bmres_iters)
        in
        let var314_variance  =
            fun289_bm_variance (var311_avg) (var308_bmres_iters)
        in
        let var315_median  =
            ( *. ) (var309_median) (1.0e+3)
        in
        let var316_sum  =
            ( *. ) (var310_sum) (1.0e+3)
        in
        let var317_avg  =
            ( *. ) (var311_avg) (1.0e+3)
        in
        let var318_max  =
            ( *. ) (var312_max) (1.0e+3)
        in
        let var319_min  =
            ( *. ) (var313_min) (1.0e+3)
        in
        let var320__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var321__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var322__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'1'; '5'|])
        in
        let var323__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var324__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var325__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var315_median))
        in
        let var326__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var327__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var328__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var318_max))
        in
        let var329__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var330__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var331__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var319_min))
        in
        let var332__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var333__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var334__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var317_avg))
        in
        let var335__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var336__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var337__  =
            fun301_bm_printarr (var308_bmres_iters)
        in
        let var338__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var339__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var340__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var314_variance))
        in
        let var341__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var342_median  =
            fun247_bm_median (var306_bmres_warmup)
        in
        let var343_sum  =
            fun255_bm_sum (var306_bmres_warmup)
        in
        let var344_avg  =
            ( /. ) (var343_sum) (4.0e+0)
        in
        let var345_max  =
            fun264_bm_max (var306_bmres_warmup)
        in
        let var346_min  =
            fun273_bm_min (var306_bmres_warmup)
        in
        let var347_variance  =
            fun289_bm_variance (var344_avg) (var306_bmres_warmup)
        in
        let var348_median  =
            ( *. ) (var342_median) (1.0e+3)
        in
        let var349_sum  =
            ( *. ) (var343_sum) (1.0e+3)
        in
        let var350_avg  =
            ( *. ) (var344_avg) (1.0e+3)
        in
        let var351_max  =
            ( *. ) (var345_max) (1.0e+3)
        in
        let var352_min  =
            ( *. ) (var346_min) (1.0e+3)
        in
        let var353__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'; '\n'; '['; 'w'; 'a'; 'r'; 'm'; 'u'; 'p'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var354__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var355__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'4'|])
        in
        let var356__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var357__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var358__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var348_median))
        in
        let var359__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var360__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var361__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var351_max))
        in
        let var362__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var363__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var364__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var352_min))
        in
        let var365__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var366__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var367__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var350_avg))
        in
        let var368__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var369__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var370__  =
            fun301_bm_printarr (var306_bmres_warmup)
        in
        let var371__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var372__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var373__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var347_variance))
        in
        let var374__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        ()
    in
    ()