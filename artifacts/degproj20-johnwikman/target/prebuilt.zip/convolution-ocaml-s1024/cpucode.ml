open Printf



let main =
    let fun1_head arg0_s =
        Array.get (arg0_s) (0)
    in
    let fun3_tail arg2_s =
        (fun xs start len -> Array.sub xs (min ((Array.length xs) - 1) start) (min ((Array.length xs) - start) len)) (arg2_s) (1) (Array.length (arg2_s))
    in
    let fun5_null arg4_l =
        ( = ) (Array.length (arg4_l)) (0)
    in
    let fun8_map arg6_f arg7_seq =
        Array.map (arg6_f) (arg7_seq)
    in
    let fun11_mapi arg9_f arg10_seq =
        Array.mapi (arg9_f) (arg10_seq)
    in
    let fun14_seqInit arg12_size arg13_f =
        Array.init (arg12_size) (arg13_f)
    in
    let rec fun16_int2string_rechelper arg17_n =
            if ( < ) (arg17_n) (10) then
                [|char_of_int (( + ) (arg17_n) (int_of_char ('0')))|]
            else
                let var18_d  =
                    [|char_of_int (( + ) (( mod ) (arg17_n) (10)) (int_of_char ('0')))|]
                in
                Array.append (fun16_int2string_rechelper (( / ) (arg17_n) (10))) (var18_d)
    in
    let fun19_int2string arg15_n =
        if ( < ) (arg15_n) (0) then
            (fun x xs -> Array.append [|x|] xs) ('-') (fun16_int2string_rechelper (( ~- ) (arg15_n)))
        else
            fun16_int2string_rechelper (arg15_n)
    in
    let fun21_float2string arg20_f =
        Array.of_seq (String.to_seq (string_of_float (arg20_f)))
    in
    let rec fun22_strJoin arg23_delim arg24_strs =
            if ( = ) (Array.length (arg24_strs)) (0) then
                [||]
            else
                if ( = ) (Array.length (arg24_strs)) (1) then
                    fun1_head (arg24_strs)
                else
                    Array.append (Array.append (fun1_head (arg24_strs)) (arg23_delim)) (fun22_strJoin (arg23_delim) (fun3_tail (arg24_strs)))
    in
    let fun26_printint arg25_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg25_i))
    in
    let fun28_printintln arg27_i =
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (Array.append (fun19_int2string (arg27_i)) ([|'\n'|]))
    in
    let rec fun31_printloop arg33_arr arg32_i =
            if ( = ) (arg32_i) (Array.length (arg33_arr)) then
                ()
            else
                let var34__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var35__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg32_i))
                in
                let var36__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var37__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg33_arr) (arg32_i)))
                in
                let var38__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun31_printloop (arg33_arr) (( + ) (arg32_i) (1))
    in
    let fun42_printintarr arg29_name arg30_arr =
        let var39__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var40__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg29_name)
        in
        let var41__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun31_printloop (arg30_arr) (0)
    in
    let rec fun45_printloop arg47_arr arg46_i =
            if ( = ) (arg46_i) (Array.length (arg47_arr)) then
                ()
            else
                let var48__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '; ' '; ' '; ' '|])
                in
                let var49__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (arg46_i))
                in
                let var50__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; ' '|])
                in
                let var51__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg47_arr) (arg46_i)))
                in
                let var52__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
                in
                fun45_printloop (arg47_arr) (( + ) (arg46_i) (1))
    in
    let fun56_printfloatarr arg43_name arg44_arr =
        let var53__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'C'; 'o'; 'n'; 't'; 'e'; 'n'; 't'; 's'; ' '; 'o'; 'f'; ' '|])
        in
        let var54__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (arg43_name)
        in
        let var55__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|':'; '\n'|])
        in
        fun45_printloop (arg44_arr) (0)
    in
    let rec fun59_printloop arg62_vec arg61_size arg60_i =
            if ( = ) (arg60_i) (arg61_size) then
                ()
            else
                let var63__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun19_int2string (Array.get (arg62_vec) (arg60_i)))
                in
                let var64__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun59_printloop (arg62_vec) (arg61_size) (( + ) (arg60_i) (1))
    in
    let fun66_printSeqi arg57_size arg58_vec =
        let var65__  =
            fun59_printloop (arg58_vec) (arg57_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let rec fun69_printloop arg72_vec arg71_size arg70_i =
            if ( = ) (arg70_i) (arg71_size) then
                ()
            else
                let var73__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (Array.get (arg72_vec) (arg70_i)))
                in
                let var74__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|' '|])
                in
                fun69_printloop (arg72_vec) (arg71_size) (( + ) (arg70_i) (1))
    in
    let fun76_printSeqf arg67_size arg68_vec =
        let var75__  =
            fun69_printloop (arg68_vec) (arg67_size) (0)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
    in
    let fun80_matrixMkf arg77_rows arg78_cols arg79_v =
        Array.make (( * ) (arg77_rows) (arg78_cols)) (arg79_v)
    in
    let fun86_matrixGetf arg81_row arg82_col arg83_m_rows arg84_m_cols arg85_m =
        Array.get (arg85_m) (( + ) (( * ) (arg84_m_cols) (arg81_row)) (arg82_col))
    in
    let fun95_seqInitFun arg94_f arg91_cols arg90_i =
        let var92_row  =
            ( / ) (arg90_i) (arg91_cols)
        in
        let var93_col  =
            ( mod ) (arg90_i) (arg91_cols)
        in
        arg94_f (var92_row) (var93_col)
    in
    let fun96_matrixInitf arg87_rows arg88_cols arg89_f =
        fun14_seqInit (( * ) (arg87_rows) (arg88_cols)) (fun95_seqInitFun (arg89_f) (arg88_cols))
    in
    let rec fun100_printrc arg107_m arg104_m_cols arg103_m_rows arg101_row arg102_col =
            if ( = ) (arg101_row) (arg103_m_rows) then
                [||]
            else
                let var105_next_col  =
                    ( mod ) (( + ) (arg102_col) (1)) (arg104_m_cols)
                in
                let var106_next_row  =
                    if ( = ) (var105_next_col) (0) then
                        ( + ) (arg101_row) (1)
                    else
                        arg101_row
                in
                fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg101_row) (arg102_col) (arg103_m_rows) (arg104_m_cols) (arg107_m)); if ( = ) (var105_next_col) (0) then
                    [|'\n'|]
                else
                    [|' '|]; fun100_printrc (arg107_m) (arg104_m_cols) (arg103_m_rows) (var106_next_row) (var105_next_col)|])
    in
    let fun108_matrix2strf arg97_m_rows arg98_m_cols arg99_m =
        fun100_printrc (arg99_m) (arg98_m_cols) (arg97_m_rows) (0) (0)
    in
    let rec fun112_printrc arg119_m arg116_m_cols arg115_m_rows arg113_row arg114_col =
            if ( = ) (arg113_row) (arg115_m_rows) then
                [||]
            else
                let var117_next_col  =
                    ( mod ) (( + ) (arg114_col) (1)) (arg116_m_cols)
                in
                let var118_next_row  =
                    if ( = ) (var117_next_col) (0) then
                        ( + ) (arg113_row) (1)
                    else
                        arg113_row
                in
                let var120__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun22_strJoin ([||]) ([|fun21_float2string (fun86_matrixGetf (arg113_row) (arg114_col) (arg115_m_rows) (arg116_m_cols) (arg119_m)); if ( = ) (var117_next_col) (0) then
                        [|'\n'|]
                    else
                        [|' '|]|]))
                in
                fun112_printrc (arg119_m) (arg116_m_cols) (arg115_m_rows) (var118_next_row) (var117_next_col)
    in
    let fun121_printMatrixf arg109_m_rows arg110_m_cols arg111_m =
        fun112_printrc (arg111_m) (arg110_m_cols) (arg109_m_rows) (0) (0)
    in
    let rec fun132_dotprod arg140_b_cols arg139_b arg138_a arg137_innerDim arg133_acc arg134_p arg135_a_offset arg136_b_offset =
            if ( = ) (arg134_p) (arg137_innerDim) then
                arg133_acc
            else
                fun132_dotprod (arg140_b_cols) (arg139_b) (arg138_a) (arg137_innerDim) (( +. ) (arg133_acc) (( *. ) (Array.get (arg138_a) (arg135_a_offset)) (Array.get (arg139_b) (arg136_b_offset)))) (( + ) (arg134_p) (1)) (( + ) (arg135_a_offset) (1)) (( + ) (arg136_b_offset) (arg140_b_cols))
    in
    let fun141_matrixMulfWorker arg122_innerDim arg123_a_rows arg124_b_cols arg125_a arg126_b arg127_idx =
        let var128_row  =
            ( / ) (arg127_idx) (arg124_b_cols)
        in
        let var129_col  =
            ( mod ) (arg127_idx) (arg124_b_cols)
        in
        let var130_a_start_offset  =
            ( * ) (arg122_innerDim) (var128_row)
        in
        let var131_b_start_offset  =
            var129_col
        in
        fun132_dotprod (arg124_b_cols) (arg126_b) (arg125_a) (arg122_innerDim) (0.0) (0) (var130_a_start_offset) (var131_b_start_offset)
    in
    let rec fun152_dotprod arg159_outerDim arg158_a arg157_innerDim arg153_acc arg154_p arg155_aT_offset arg156_a_offset =
            if ( = ) (arg154_p) (arg157_innerDim) then
                arg153_acc
            else
                fun152_dotprod (arg159_outerDim) (arg158_a) (arg157_innerDim) (( +. ) (arg153_acc) (( *. ) (Array.get (arg158_a) (arg155_aT_offset)) (Array.get (arg158_a) (arg156_a_offset)))) (( + ) (arg154_p) (1)) (( + ) (arg155_aT_offset) (arg159_outerDim)) (( + ) (arg156_a_offset) (arg159_outerDim))
    in
    let fun160_matrixATAfWorker arg142_rows arg143_cols arg144_a arg145_idx =
        let var146_innerDim  =
            arg142_rows
        in
        let var147_outerDim  =
            arg143_cols
        in
        let var148_row  =
            ( / ) (arg145_idx) (arg143_cols)
        in
        let var149_col  =
            ( mod ) (arg145_idx) (arg143_cols)
        in
        let var150_aT_start_offset  =
            var148_row
        in
        let var151_a_start_offset  =
            var149_col
        in
        fun152_dotprod (var147_outerDim) (arg144_a) (var146_innerDim) (0.0) (0) (var150_aT_start_offset) (var151_a_start_offset)
    in
    let rec fun172_dotprodTransposeLhs arg181_b_cols arg180_a_cols arg179_b arg178_a arg177_b_rows arg173_acc arg174_p arg175_aT_offset arg176_b_offset =
            if ( = ) (arg174_p) (arg177_b_rows) then
                arg173_acc
            else
                fun172_dotprodTransposeLhs (arg181_b_cols) (arg180_a_cols) (arg179_b) (arg178_a) (arg177_b_rows) (( +. ) (arg173_acc) (( *. ) (Array.get (arg178_a) (arg175_aT_offset)) (Array.get (arg179_b) (arg176_b_offset)))) (( + ) (arg174_p) (1)) (( + ) (arg175_aT_offset) (arg180_a_cols)) (( + ) (arg176_b_offset) (arg181_b_cols))
    in
    let fun182_matrixMulTransposeLhsfWorker arg161_a_rows arg162_a_cols arg163_b_rows arg164_b_cols arg165_a arg166_b arg167_idx =
        let var168_row  =
            ( / ) (arg167_idx) (arg164_b_cols)
        in
        let var169_col  =
            ( mod ) (arg167_idx) (arg164_b_cols)
        in
        let var170_aT_start_offset  =
            var168_row
        in
        let var171_b_start_offset  =
            var169_col
        in
        fun172_dotprodTransposeLhs (arg164_b_cols) (arg162_a_cols) (arg166_b) (arg165_a) (arg163_b_rows) (0.0) (0) (var170_aT_start_offset) (var171_b_start_offset)
    in
    let fun187_matAinitfun_v3 arg185_row arg186_col =
        ( -. ) (( /. ) (float_of_int (( mod ) (( * ) (arg185_row) (arg185_row)) (( + ) (arg186_col) (17)))) (3.991000e+0)) (1.400000e-2)
    in
    let fun189_filter17initfun arg188_i =
        ( -. ) (1.250e+0) (( /. ) (1.0e-0) (( +. ) (float_of_int (arg188_i)) (1.0e-0)))
    in
    let rec fun202_work arg207_filter arg206_originalOffset arg205_mat arg203_acc arg204_i =
            if ( = ) (arg204_i) (17) then
                arg203_acc
            else
                fun202_work (arg207_filter) (arg206_originalOffset) (arg205_mat) (( +. ) (arg203_acc) (( *. ) (Array.get (arg205_mat) (( + ) (arg206_originalOffset) (arg204_i))) (Array.get (arg207_filter) (arg204_i)))) (( + ) (arg204_i) (1))
    in
    let fun208_convolute17Worker arg190_filter arg191_rows arg192_cols arg193_mat arg194_idx =
        let var195_row  =
            ( / ) (arg194_idx) (arg192_cols)
        in
        let var196_col  =
            ( mod ) (arg194_idx) (arg192_cols)
        in
        let var197_originalRows  =
            arg191_rows
        in
        let var198_originalCols  =
            ( + ) (arg192_cols) (16)
        in
        let var199_originalRow  =
            var195_row
        in
        let var200_originalCol  =
            ( + ) (var196_col) (8)
        in
        let var201_originalOffset  =
            ( - ) (( + ) (( * ) (var199_originalRow) (var198_originalCols)) (var200_originalCol)) (8)
        in
        fun202_work (arg190_filter) (var201_originalOffset) (arg193_mat) (0.0) (0)
    in
    let fun221_bm_runonce arg218_matA arg217_filter17 arg216_resCols arg215_resRows arg213__ =
        let var214_bm_t_start  =
            Unix.gettimeofday (())
        in
        let var219_matRes  =
            fun14_seqInit (( * ) (arg215_resRows) (arg216_resCols)) (fun208_convolute17Worker (arg217_filter17) (arg215_resRows) (arg216_resCols) (arg218_matA))
        in
        let var220_bm_t_end  =
            Unix.gettimeofday (())
        in
        ( -. ) (var220_bm_t_end) (var214_bm_t_start)
    in
    let rec fun223_bm_iter arg231_resRows arg230_resCols arg229_filter17 arg228_matA arg226_n arg224_i arg225_acc =
            if ( >= ) (arg224_i) (arg226_n) then
                arg225_acc
            else
                let var227__  =
                    ()
                in
                let var232_res  =
                    fun221_bm_runonce (arg228_matA) (arg229_filter17) (arg230_resCols) (arg231_resRows) (())
                in
                let var233_newacc  =
                    Array.append (arg225_acc) ([|var232_res|])
                in
                fun223_bm_iter (arg231_resRows) (arg230_resCols) (arg229_filter17) (arg228_matA) (arg226_n) (( + ) (arg224_i) (1)) (var233_newacc)
    in
    let fun238_bm_runmultiple arg237_matA arg236_filter17 arg235_resCols arg234_resRows arg222_n =
        fun223_bm_iter (arg234_resRows) (arg235_resCols) (arg236_filter17) (arg237_matA) (arg222_n) (0) ([||])
    in
    let rec fun241_quicksort_rec arg243_pivot arg244_lt_pivot arg245_geq_pivot arg246_remaining =
            if ( = ) (Array.length (arg246_remaining)) (0) then
                let var247_seq_lt  =
                    fun242_quicksort (arg244_lt_pivot)
                in
                let var248_seq_pivot  =
                    [|arg243_pivot|]
                in
                let var249_seq_geq  =
                    fun242_quicksort (arg245_geq_pivot)
                in
                Array.append (Array.append (var247_seq_lt) (var248_seq_pivot)) (var249_seq_geq)
            else
                let var250_e  =
                    fun1_head (arg246_remaining)
                in
                let var251_t  =
                    fun3_tail (arg246_remaining)
                in
                if ( < ) (var250_e) (arg243_pivot) then
                    fun241_quicksort_rec (arg243_pivot) ((fun x xs -> Array.append [|x|] xs) (var250_e) (arg244_lt_pivot)) (arg245_geq_pivot) (var251_t)
                else
                    fun241_quicksort_rec (arg243_pivot) (arg244_lt_pivot) ((fun x xs -> Array.append [|x|] xs) (var250_e) (arg245_geq_pivot)) (var251_t)
        and fun242_quicksort arg252_arr =
            if ( <= ) (Array.length (arg252_arr)) (1) then
                arg252_arr
            else
                fun241_quicksort_rec (fun1_head (arg252_arr)) ([||]) ([||]) (fun3_tail (arg252_arr))
    in
    let fun253_bm_sort arg239_arr =
        let var240_n  =
            Array.length (arg239_arr)
        in
        fun242_quicksort (arg239_arr)
    in
    let fun257_bm_median arg254_arr =
        let var255_n  =
            Array.length (arg254_arr)
        in
        let var256_sorted  =
            fun253_bm_sort (arg254_arr)
        in
        if ( = ) (( mod ) (var255_n) (2)) (0) then
            ( /. ) (( +. ) (Array.get (arg254_arr) (( - ) (( / ) (var255_n) (2)) (1))) (Array.get (arg254_arr) (( / ) (var255_n) (2)))) (2.0e+0)
        else
            Array.get (arg254_arr) (( / ) (var255_n) (2))
    in
    let rec fun260_work arg264_arr arg263_n arg261_i arg262_acc =
            if ( = ) (arg261_i) (arg263_n) then
                arg262_acc
            else
                fun260_work (arg264_arr) (arg263_n) (( + ) (arg261_i) (1)) (( +. ) (arg262_acc) (Array.get (arg264_arr) (arg261_i)))
    in
    let fun265_bm_sum arg258_arr =
        let var259_n  =
            Array.length (arg258_arr)
        in
        fun260_work (arg258_arr) (var259_n) (0) (0.0)
    in
    let rec fun268_work arg272_arr arg271_n arg269_i arg270_acc =
            if ( = ) (arg269_i) (arg271_n) then
                arg270_acc
            else
                let var273_e  =
                    Array.get (arg272_arr) (arg269_i)
                in
                fun268_work (arg272_arr) (arg271_n) (( + ) (arg269_i) (1)) (if ( > ) (var273_e) (arg270_acc) then
                    var273_e
                else
                    arg270_acc)
    in
    let fun274_bm_max arg266_arr =
        let var267_n  =
            Array.length (arg266_arr)
        in
        fun268_work (arg266_arr) (var267_n) (1) (Array.get (arg266_arr) (0))
    in
    let rec fun277_work arg281_arr arg280_n arg278_i arg279_acc =
            if ( = ) (arg278_i) (arg280_n) then
                arg279_acc
            else
                let var282_e  =
                    Array.get (arg281_arr) (arg278_i)
                in
                fun277_work (arg281_arr) (arg280_n) (( + ) (arg278_i) (1)) (if ( < ) (var282_e) (arg279_acc) then
                    var282_e
                else
                    arg279_acc)
    in
    let fun283_bm_min arg275_arr =
        let var276_n  =
            Array.length (arg275_arr)
        in
        fun277_work (arg275_arr) (var276_n) (1) (Array.get (arg275_arr) (0))
    in
    let rec fun288_work arg294_avg_co arg292_arr arg291_n arg289_i arg290_acc =
            if ( = ) (arg289_i) (arg291_n) then
                arg290_acc
            else
                let var293_elem  =
                    ( *. ) (Array.get (arg292_arr) (arg289_i)) (1.0e+3)
                in
                let var295_subres  =
                    ( -. ) (arg294_avg_co) (var293_elem)
                in
                fun288_work (arg294_avg_co) (arg292_arr) (arg291_n) (( + ) (arg289_i) (1)) (( +. ) (arg290_acc) (( *. ) (var295_subres) (var295_subres)))
    in
    let fun299_bm_variance arg284_avg arg285_arr =
        let var286_n  =
            Array.length (arg285_arr)
        in
        let var287_avg_co  =
            ( *. ) (arg284_avg) (1.0e+3)
        in
        let var296_elem  =
            ( *. ) (Array.get (arg285_arr) (0)) (1.0e+3)
        in
        let var297_subres  =
            ( -. ) (var287_avg_co) (var296_elem)
        in
        let var298_res  =
            fun288_work (var287_avg_co) (arg285_arr) (var286_n) (1) (( *. ) (var297_subres) (var297_subres))
        in
        ( /. ) (var298_res) (float_of_int (( - ) (var286_n) (1)))
    in
    let rec fun302_work arg306_arr arg304_n arg303_i =
            if ( = ) (arg303_i) (arg304_n) then
                ()
            else
                let var305__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|','; ' '|])
                in
                let var307__  =
                    (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg306_arr) (arg303_i)) (1.0e+3)))
                in
                fun302_work (arg306_arr) (arg304_n) (( + ) (arg303_i) (1))
    in
    let fun311_bm_printarr arg300_arr =
        let var301_n  =
            Array.length (arg300_arr)
        in
        let var308__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['|])
        in
        let var309__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (( *. ) (Array.get (arg300_arr) (0)) (1.0e+3)))
        in
        let var310__  =
            fun302_work (arg300_arr) (var301_n) (1)
        in
        (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|']'|])
    in
    let fun314_bm_dist arg312_a arg313_b =
        if ( > ) (arg312_a) (arg313_b) then
            ( -. ) (arg312_a) (arg313_b)
        else
            ( -. ) (arg313_b) (arg312_a)
    in
    let var183_matA_rows  =
        1024
    in
    let var184_matA_cols  =
        1024
    in
    let var209_matA  =
        fun96_matrixInitf (var183_matA_rows) (var184_matA_cols) (fun187_matAinitfun_v3)
    in
    let var210_filter17  =
        fun14_seqInit (17) (fun189_filter17initfun)
    in
    let var211_resRows  =
        var183_matA_rows
    in
    let var212_resCols  =
        ( - ) (var184_matA_cols) (16)
    in
    let var315__  =
        ()
    in
    let var316_bmres_warmup  =
        fun238_bm_runmultiple (var209_matA) (var210_filter17) (var212_resCols) (var211_resRows) (4)
    in
    let var317__  =
        ()
    in
    let var318_bmres_iters  =
        fun238_bm_runmultiple (var209_matA) (var210_filter17) (var212_resCols) (var211_resRows) (15)
    in
    let var385__  =
        let var319_median  =
            fun257_bm_median (var318_bmres_iters)
        in
        let var320_sum  =
            fun265_bm_sum (var318_bmres_iters)
        in
        let var321_avg  =
            ( /. ) (var320_sum) (1.50e+1)
        in
        let var322_max  =
            fun274_bm_max (var318_bmres_iters)
        in
        let var323_min  =
            fun283_bm_min (var318_bmres_iters)
        in
        let var324_variance  =
            fun299_bm_variance (var321_avg) (var318_bmres_iters)
        in
        let var325_median  =
            ( *. ) (var319_median) (1.0e+3)
        in
        let var326_sum  =
            ( *. ) (var320_sum) (1.0e+3)
        in
        let var327_avg  =
            ( *. ) (var321_avg) (1.0e+3)
        in
        let var328_max  =
            ( *. ) (var322_max) (1.0e+3)
        in
        let var329_min  =
            ( *. ) (var323_min) (1.0e+3)
        in
        let var330__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'['; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var331__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var332__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'1'; '5'|])
        in
        let var333__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var334__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var335__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var325_median))
        in
        let var336__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var337__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var338__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var328_max))
        in
        let var339__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var340__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var341__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var329_min))
        in
        let var342__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var343__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var344__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var327_avg))
        in
        let var345__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var346__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var347__  =
            fun311_bm_printarr (var318_bmres_iters)
        in
        let var348__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var349__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var350__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var324_variance))
        in
        let var351__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var352_median  =
            fun257_bm_median (var316_bmres_warmup)
        in
        let var353_sum  =
            fun265_bm_sum (var316_bmres_warmup)
        in
        let var354_avg  =
            ( /. ) (var353_sum) (4.0e+0)
        in
        let var355_max  =
            fun274_bm_max (var316_bmres_warmup)
        in
        let var356_min  =
            fun283_bm_min (var316_bmres_warmup)
        in
        let var357_variance  =
            fun299_bm_variance (var354_avg) (var316_bmres_warmup)
        in
        let var358_median  =
            ( *. ) (var352_median) (1.0e+3)
        in
        let var359_sum  =
            ( *. ) (var353_sum) (1.0e+3)
        in
        let var360_avg  =
            ( *. ) (var354_avg) (1.0e+3)
        in
        let var361_max  =
            ( *. ) (var355_max) (1.0e+3)
        in
        let var362_min  =
            ( *. ) (var356_min) (1.0e+3)
        in
        let var363__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'; '\n'; '['; 'w'; 'a'; 'r'; 'm'; 'u'; 'p'; '_'; 'r'; 'e'; 's'; 'u'; 'l'; 't'; 's'; ']'; '\n'|])
        in
        let var364__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'n'; 'o'; '_'; 'o'; 'f'; '_'; 'i'; 't'; 'e'; 'r'; 'a'; 't'; 'i'; 'o'; 'n'; 's'; ' '; '='; ' '|])
        in
        let var365__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'4'|])
        in
        let var366__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var367__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'m'; 'e'; 'd'; 'i'; 'a'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var368__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var358_median))
        in
        let var369__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var370__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'l'; 'o'; 'n'; 'g'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var371__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var361_max))
        in
        let var372__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var373__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'s'; 'h'; 'o'; 'r'; 't'; 'e'; 's'; 't'; '_'; 'r'; 'u'; 'n'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var374__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var362_min))
        in
        let var375__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var376__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'a'; 'v'; 'e'; 'r'; 'a'; 'g'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var377__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var360_avg))
        in
        let var378__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var379__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'p'; 'o'; 'i'; 'n'; 't'; 's'; ' '; '='; ' '|])
        in
        let var380__  =
            fun311_bm_printarr (var316_bmres_warmup)
        in
        let var381__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        let var382__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'v'; 'a'; 'r'; 'i'; 'a'; 'n'; 'c'; 'e'; '_'; 'm'; 's'; ' '; '='; ' '|])
        in
        let var383__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) (fun21_float2string (var357_variance))
        in
        let var384__  =
            (fun s -> printf "%s" (String.of_seq (Array.to_seq s))) ([|'\n'|])
        in
        ()
    in
    ()